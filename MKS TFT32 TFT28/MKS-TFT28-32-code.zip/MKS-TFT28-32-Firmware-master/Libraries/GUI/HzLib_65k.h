#ifndef __HzLib_65k_H__
#define __HzLib_65k_H__

extern unsigned char const HzLib[];
extern unsigned char const AsciiLib[];

#endif
