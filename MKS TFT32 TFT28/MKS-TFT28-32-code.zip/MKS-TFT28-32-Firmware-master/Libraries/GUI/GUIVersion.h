/*
----------------------------------------------------------------------
File        : GUIVersion.h
Purpose     : Include file defining current GUI version
---------------------------END-OF-HEADER------------------------------
*/

#ifndef  GUI_VERSION_H
#define  GUI_VERSION_H

#define GUI_VERSION 39001

#endif   /* Avoid multiple inclusion */

/*************************** End of file ****************************/
