#ifndef FATTIME_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "integer.h"

DWORD get_fattime (void);

#ifdef __cplusplus
}
#endif
#endif
