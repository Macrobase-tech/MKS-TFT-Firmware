#ifndef _DRAW_TEMP_UI_H_
#define _DRAW_TEMP_UI_H_


extern void draw_changeSpeed();
extern void Clear_TempSpeed();


#endif

