#ifndef _DRAW_ZERO_H_
#define _DRAW_ZERO_H_

extern void draw_Zero();
extern void Clear_Zero();
#endif
