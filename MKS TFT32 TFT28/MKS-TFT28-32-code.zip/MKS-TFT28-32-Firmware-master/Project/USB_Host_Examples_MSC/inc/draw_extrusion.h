#ifndef _DRAW_EXTRUSION_H_
#define _DRAW_EXTRUSION_H_

extern void draw_extrusion();

extern void disp_extru_speed();

extern void disp_sprayer_temp();

extern void disp_sprayer_type();

extern void Clear_extrusion();

extern void disp_extru_step();

extern void disp_extru_amount();

#endif

