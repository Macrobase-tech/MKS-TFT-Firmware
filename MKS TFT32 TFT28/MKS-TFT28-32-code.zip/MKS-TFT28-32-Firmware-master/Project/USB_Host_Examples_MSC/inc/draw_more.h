#ifndef _DRAW_MORE_H_
#define _DRAW_MORE_H_

extern void draw_More();
extern void Clear_more();

#endif

