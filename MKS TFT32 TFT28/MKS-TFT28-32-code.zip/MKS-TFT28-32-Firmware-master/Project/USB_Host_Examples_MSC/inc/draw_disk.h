#ifndef _DRAW_DISK_H_
#define _DRAW_DISK_H_


void draw_Disk();

void Clear_Disk();

void disp_disk_choose();



#endif

