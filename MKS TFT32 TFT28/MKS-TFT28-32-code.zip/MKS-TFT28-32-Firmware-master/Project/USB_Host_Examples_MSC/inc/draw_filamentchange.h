#ifndef _DRAW_FILAMENTCHANGE_H_
#define _DRAW_FILAMENTCHANGE_H_

extern void draw_FilamentChange();
extern void FilamentChange_handle();
extern void Clear_FilamentChange();
extern void FilamentChange_handle();
extern void disp_filament_sprayer_temp();

#endif
