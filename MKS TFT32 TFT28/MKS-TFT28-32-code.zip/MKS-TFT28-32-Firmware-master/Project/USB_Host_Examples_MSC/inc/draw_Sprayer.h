#ifndef _DRAW_SPRAYER_H_
#define _DRAW_SPRAYER_H_

extern void draw_Sprayer();
extern void disp_sel_sprayer_num();
extern void Clear_Sprayer();
#endif

