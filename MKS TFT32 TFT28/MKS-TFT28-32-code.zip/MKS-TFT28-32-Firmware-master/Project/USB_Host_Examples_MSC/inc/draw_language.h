#ifndef _DRAW_LANGUAGE_H_
#define _DRAW_LANGUAGE_H_

extern void draw_Language();
extern void disp_sel_item();
extern void Clear_Language();


#endif

