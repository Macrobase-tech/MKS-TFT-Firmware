#ifndef _STRING_DEAL_H_
#define _STRING_DEAL_H_

void cutFileName(char *path, int len, int bytePerLine, char *outStr);

#endif
