#ifndef _DRAW_LOG_UI_H_
#define _DRAW_LOG_UI_H_

extern void draw_Connect();
extern void disp_sel_baud();
extern void Clear_Connect();

#endif

