#ifndef _DRAW_FAN_H_
#define _DRAW_FAN_H_


void draw_fan();

void disp_fan_speed();

void Clear_fan();

#endif

