#ifndef _DRAW_CHANGE_SPEED_
#define _DRAW_CHANGE_SPEED_

extern void Clear_changeSpeed();
extern void draw_changeSpeed();
extern void disp_print_speed();
extern void disp_speed_type();
extern void disp_step_speed();

#endif

