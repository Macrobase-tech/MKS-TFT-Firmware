#ifndef _TOUCH_CALIBRATE_H_
#define _TOUCH_CALIBRATE_H_

extern void Touch_Adjust();
extern void setTouchBound(int32_t x0, int32_t x1, int32_t y0, int32_t y1 );


#endif

