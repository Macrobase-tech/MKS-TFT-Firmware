#ifndef _DRAW_READY_PRINT_
#define _DRAW_READY_PRINT_

extern void disp_sprayer_temp_main();
extern void disp_bed_temp_main();
extern void disp_fan_speed_main();

extern void draw_ready_print(void);
extern void Clear_ready_print();
extern void disp_fan_move();
//extern void disp_temp_ready_print();

#endif

