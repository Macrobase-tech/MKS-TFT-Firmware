#ifndef _DRAW_MACHINE_H_
#define _DRAW_MACHINE_H_

extern void draw_Machine();
extern void disp_mach_type();
extern void Clear_Machine();

#endif

