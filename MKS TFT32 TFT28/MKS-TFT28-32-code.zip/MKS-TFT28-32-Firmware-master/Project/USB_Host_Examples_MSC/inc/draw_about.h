#ifndef _DRAW_ABOUT_H_
#define _DRAW_ABOUT_H_

extern void draw_About();
extern void Clear_About();

#endif

