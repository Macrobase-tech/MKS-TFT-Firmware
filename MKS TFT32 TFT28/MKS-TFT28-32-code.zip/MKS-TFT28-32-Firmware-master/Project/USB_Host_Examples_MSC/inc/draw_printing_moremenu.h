#ifndef _DRAW_PRINTING_MOREMENU_H_
#define _DRAW_PRINTING_MOREMENU_H_

void draw_printmore();
void Clear_Printmore();
void Autoshutdown_display();

#endif

