#ifndef _DRAW_TOOL_
#define _DRAW_TOOL_

extern void draw_tool(void);
extern void Clear_Tool();

#endif

