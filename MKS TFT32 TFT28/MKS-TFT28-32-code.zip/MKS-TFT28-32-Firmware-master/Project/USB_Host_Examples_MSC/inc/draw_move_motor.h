#ifndef _DRAW_MOVE_MOTOR_H_
#define _DRAW_MOVE_MOTOR_H_

extern void draw_move_motor();
extern void disp_move_dist();
extern void Clear_move_motor();

#endif

