#ifndef _DRAW_OPERATE_H_
#define _DRAW_OPERATE_H_


extern void draw_operate();
extern void setProBarRateOpera(int rate);
extern void disp_temp_operate();
extern void Clear_operate();

#endif

