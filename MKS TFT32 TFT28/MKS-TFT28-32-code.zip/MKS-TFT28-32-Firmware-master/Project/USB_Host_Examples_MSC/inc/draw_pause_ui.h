#ifndef _DRAW_PAUSE_UI_H_
#define _DRAW_PAUSE_UI_H_

extern void draw_pause();
extern void disp_temp_pause();

extern void Clear_pause();

#endif

