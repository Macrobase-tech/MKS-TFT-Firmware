#ifndef _DRAW_PRE_HEAT_H_
#define _DRAW_PRE_HEAT_H_

extern void draw_preHeat();

extern void Clear_preHeat();
extern void disp_step_heat();
extern void disp_desire_temp();
extern void disp_temp_type();


#endif
