#ifndef MULTI_LANGUAGE_H
#define MULTI_LANGUAGE_H

extern void disp_language_init();

//语言
#define LANG_SIMPLE_CHINESE		1
#define LANG_COMPLEX_CHINESE	2
#define LANG_ENGLISH						3
#define LANG_JAPAN							4
#define LANG_GERMAN						5		
#define LANG_FRENCH						6
#define LANG_RUSSIAN						7
#define LANG_KOREAN						8
#define LANG_TURKISH						9
#define LANG_SPANISH						10
#define LANG_GREEK							11
#define LANG_ITALY							12
#define LANG_PORTUGUESE				13



#define FONT_BUTTON	GUI_FontHZ_fontHz14
#define FONT_STATE_INF	GUI_FontHZ_fontHz14
#define FONT_TITLE		GUI_FontHZ_fontHz14

typedef struct common_menu_disp
{
	char *text_back;
	char *dialog_confirm_title;
	char *close_machine_tips;
	char *unbind_printer_tips;
	char *print_special_title;
	char *pause_special_title;
	char *operate_special_title;
}common_menu_def;
extern common_menu_def common_menu;

typedef struct main_menu_disp
{
	char *title;
	char *preheat;
	char *move;
	char *home;
	char *print;
	char *extrude;
	char *leveling;
	char *autoleveling;
	char *set;
	char *tool;
	char *more;
}main_menu_def;
extern main_menu_def main_menu;
typedef struct preheat_menu_disp
{
	char *adjust_title;
	char *title;
	char *add;
	char *dec;
	char *ext1;
	char *ext2;
	char *hotbed;
	char *off;
	char *step_1c;
	char *step_5c;
	char *step_10c;
	char *back;
	
	char *dialog_tips;
	
}preheat_menu_def;
extern preheat_menu_def preheat_menu;
typedef struct move_menu_disp
{
	char *title;
	char *x_add;
	char *x_dec;
	char *y_add;
	char *y_dec;
	char *z_add;
	char *z_dec;
	char *step_001mm;
	char *step_005mm;
	char *step_01mm;
	char *step_1mm;
	char *step_10mm;
	char *back;
}move_menu_def;
extern move_menu_def move_menu;
typedef struct home_menu_disp
{
	char *title;
	char *home_all;
	char *home_x;
	char *home_y;
	char *home_z;
	char *back;
}home_menu_def;
extern home_menu_def home_menu;
typedef struct file_menu_disp
{
	char *title;
	char *page_up;
	char *page_down;
	char *back;

	char *file_loading;
	char *no_file;
	char *no_file_and_check;
	char *no_desire_temp;
	
}file_menu_def;
extern file_menu_def file_menu;
typedef struct extrude_menu_disp
{
	char *title;
	char *in;
	char *out;
	char *ext1;
	char *ext2;
	char *step_1mm;
	char *step_5mm;
	char *step_10mm;
	char *low;
	char *normal;
	char *high;
	char *back;

	char *count_tips;
	char *temp_tips;
	
}extrude_menu_def;
extern extrude_menu_def extrude_menu;
typedef struct leveling_menu_disp
{
	char *title;
	char *position1;
	char *position2;
	char *position3;
	char *position4;
	char *position5;
	
	char *back;
}leveling_menu_def;
extern leveling_menu_def leveling_menu;
typedef struct set_menu_disp
{
	char *title;
	char *filesys;
	char *wifi;
	char *about;
	char *fan;
	char *filament;
	char *breakpoint;
	char *motoroff;
	char *shutdown;
	char *language;
	char *back;
}set_menu_def;
extern set_menu_def set_menu;
typedef struct filesys_menu_disp
{
char *title;
char *filesys;
char *sd_sys;
char *usb_sys;
char *back;

}filesys_menu_def;
extern filesys_menu_def filesys_menu;
typedef struct more_menu_disp
{
	char *title;
	char *back;
}more_menu_def;
extern more_menu_def more_menu;
typedef struct wifi_menu_disp
{
	char *title;
	char *ip;
	char *wifi;
	char *key;
	char *state_ap;
	char *state_sta;
	char *cloud;
	char *connected;
	char *disconnected;
	char *exception;
	char *back;
	char *wifi_state_enable;
	char *wifi_state_disable;
	char *enable_wifi;
	char *disable_wifi;
}wifi_menu_def;
extern wifi_menu_def wifi_menu;
typedef struct cloud_menu_disp
{
	char *title;
	char *unbind;
	char *unbinding;
	char *unbinded;
	char *bind; 
	char *binding;
	char *binded;
	char *disable;
	char *disconnected;
	char *back;
	char *unbind_printer_tips;
}cloud_menu_def;
extern cloud_menu_def cloud_menu;

typedef struct about_menu_disp
{
	char *title;
	char *type;
	char *version; 
	char *wifi;
	char *type_robin;
	char *type_robin_mini;
	char *back;
}about_menu_def;
extern about_menu_def about_menu;

typedef struct fan_menu_disp
{
	char *title;
	char *add;
	char *dec; 
	char *full;
	char *half;
	char *off;
	char *back;
	char *state;
}fan_menu_def;
extern fan_menu_def fan_menu;

typedef struct filament_menu_disp
{
	char *title;
	char *in;
	char *out; 
	char *ext1;
	char *ext2;
	char *back;
	char *stat_temp;
	char *ready_replace;
	char *replacing;
	char *loading;
	char *unloading;
	char *heating;
	char *complete_and_back;
	char *filament_dialog_load_heat;
	char *filament_dialog_unload_heat;
	char *filament_dialog_load_heat_confirm;
	char *filament_dialog_unload_heat_confirm;
	char *filament_dialog_loading;
	char *filament_dialog_unloading;
	char *filament_dialog_load_completed;
	char *filament_dialog_unload_completed;
	char *filament_dialog_ok;
	char *filament_dialog_back;
	char *filamemt_dialog_empty;
}filament_menu_def;
extern filament_menu_def filament_menu;

typedef struct language_menu
{
	char *title;
	char *chinese_s;
	char *chinese_t;
	char *english;
	char *russian;
	char *japan;
	char *italy;
	char *german;
	char *spanish;
	char *korean;
	char *french;
	char *brazil;
	char *portuguese;
	char *next;
	char *up;
	char *back;
}language_menu_def;
extern language_menu_def language_menu;


typedef struct printing_menu_disp
{
	char *title;
	char *option;
	char *temp1; 
	char *temp2;
	char *bed_temp;
	char *fan_speed;	
}printing_menu_def;
extern printing_menu_def printing_menu;

typedef struct operation_menu_disp
{
	char *title;
	char *pause;
	char *stop; 
	char *temp;
	char *filament;
	char *more;	
	char *back;
}operation_menu_def;
extern operation_menu_def operation_menu;
typedef struct pause_menu_disp
{
	char *title;
	char *resume;
	char *stop; 
	char *extrude;
	char *move;
	char *filament;	
	char *more;
}pause_menu_def;
extern pause_menu_def pause_menu;

typedef struct speed_menu_disp
{
	char *title;
	char *add;
	char *dec; 
	char *extrude;
	char *move;
	char *step_1percent;
	char *step_5percent;
	char *step_10percent;
	char *back;
	char *move_speed;
	char *extrude_speed;
}speed_menu_def;
extern speed_menu_def speed_menu;

typedef struct printing_more_menu_disp
{
	char *title;
	char *fan;
	char *auto_close; 
	char *manual;
	char *temp;	
	char *speed;
	char *back;
	char *babystep;
}printing_more_menu_def;
extern printing_more_menu_def printing_more_menu;

typedef struct dialog_menu_disp
{
	char *confirm_title;
	
	char *error1_repint_no_file;
	char *error2_communication_fail;
	char *error3_filename_too_long;
	char *error4_no_file;
	char *error5_check_filesys;

	char *tip1_print_file;
	char *tip2_stop_file;
}dialog_menu_def;
extern dialog_menu_def dialog_menu;

typedef struct print_file_dialog_disp
{
	char *title;
	char *confirm;
	char *cancle;
	char *print_file;
	char *cancle_print;
	char *retry;
	char *stop;
	char *no_file_print_tips;
	char *print_from_breakpoint;
	char *file_name_too_long_error;
	char *close_machine_error;
	char *defaulty;
	char *setting;
}print_file_dialog_menu_def;
extern print_file_dialog_menu_def print_file_dialog_menu;
/*****************************************/
//********************************************//
#define TEXT_1C						"1℃"
#define TEXT_5C						"5℃"
#define TEXT_10C					"10℃"

#define AXIS_X_ADD_TEXT			    "X+"
#define AXIS_X_DEC_TEXT			    "X-"
#define AXIS_Y_ADD_TEXT			    "Y+"
#define AXIS_Y_DEC_TEXT			    "Y-"
#define AXIS_Z_ADD_TEXT			    "Z+"
#define AXIS_Z_DEC_TEXT			    "Z-"
#define TEXT_01MM					"0.1mm"
#define TEXT_1MM					"1mm"
#define TEXT_10MM					"10mm"
#define TEXT_001MM					"0.01mm"
#define TEXT_005MM					"0.05mm"


#define EXTRUDE_1MM_TEXT			"1mm"
#define EXTRUDE_5MM_TEXT			"5mm"
#define EXTRUDE_10MM_TEXT		    "10mm"

#define STEP_1PERCENT				"1%"
#define STEP_5PERCENT				"5%"
#define STEP_10PERCENT				"10%"

#define LANGUAGE_S_CN				"简体"
#define LANGUAGE_T_CN				"繁体"
#define LANGUAGE_EN					"English"
#define LANGUAGE_JP					"日本語"
#define LANGUAGE_GE					"Deutsch"
#define LANGUAGE_FR					"français"
#define LANGUAGE_IT                 "Italia"
#define LANGUAGE_PR                 "português"
#define LANGUAGE_KR                 "Korean"
#define LANGUAGE_BR                 "Brazil"
#define LANGUAGE_RU                 "русский"
#define LANGUAGE_SP                 "español"

#define HOME_X_TEXT					"X"
#define HOME_Y_TEXT					"Y"
#define HOME_Z_TEXT					"Z"
#define HOME_ALL_TEXT				"All"

#define ABOUT_TYPE_TEXT				"TYPE: MKS tft"
#define ABOUT_VERSION_TEXT			"VERSION: 3.0.5"
#define ABOUT_WIFI_TEXT				"WIFI:"

#define FAN_OPEN_TEXT				"100%"
#define FAN_HALF_TEXT				"50%"
#define FAN_CLOSE_TEXT				"0%"
#define FAN_TIPS1_TEXT				"FAN"
#define FAN_TIPS2_TEXT				"FAN\nClose"

#define WIFI_TEXT					"WIFI"
#define WIFI_IP_TEXT			"IP:"
#define WIFI_NAME_TEXT		"WiFi:"
#define WIFI_KEY_TEXT		"Key:"
#define WIFI_STATE_AP_TEXT			"State: AP"
#define WIFI_STATE_STA_TEXT			"State: STA"
#define WIFI_CONNECTED_TEXT			"Connected"
#define WIFI_DISCONNECTED_TEXT  "Disconnected"
#define WIFI_EXCEPTION_TEXT				"Exception"

#define FILAMENT_TIPS2_TEXT			"T:"

#define DIALOG_UPLOAD_ING_EN				"Uploading......"
#define DIALOG_UPLOAD_ERROR_EN				"Upload error"
#define DIALOG_UPLOAD_FINISH_EN				"Upload finished"
#define DIALOG_UPLOAD_SIZE_EN				"Size"
#define DIALOG_UPLOAD_TIME_EN				"Time"
#define DIALOG_UPLOAD_SPEED_EN				"Speed"
#define DIALOG_UPDATE_WIFI_FIRMWARE_EN		"Updating wifi model firmware"
#define DIALOG_UPDATE_WIFI_WEB_EN			"Updating wifi model web data"

#define BABYSTEP_EN         "Babystep"

//*************简体中文***********************//
#define TOOL_TEXT_CN			    "工具"
#define PREHEAT_TEXT_CN 	        "预热"
#define	MOVE_TEXT_CN				"移动"
#define HOME_TEXT_CN 		        "回零"
#define PRINT_TEXT_CN		        "打印"
#define EXTRUDE_TEXT_CN 	        "挤出"
#define LEVELING_TEXT_CN            "调平"
#define AUTO_LEVELING_TEXT_CN       "自动调平"
#define SET_TEXT_CN			        "设置"
#define MORE_TEXT_CN                "更多"

#define ADD_TEXT_CN			        "增加"
#define DEC_TEXT_CN			        "减少"
#define EXTRUDER_1_TEXT_CN		    "喷头1"
#define EXTRUDER_2_TEXT_CN		    "喷头2"
#define HEATBED_TEXT_CN			    "热床"
#define TEXT_1C_CN					"1℃"
#define TEXT_5C_CN					"5℃"
#define TEXT_10C_CN					"10℃"
#define CLOSE_TEXT_CN				"关闭"

#define BACK_TEXT_CN					"返回"

#define AXIS_X_ADD_TEXT_CN				"X+"
#define AXIS_X_DEC_TEXT_CN				"X-"
#define AXIS_Y_ADD_TEXT_CN				"Y+"
#define AXIS_Y_DEC_TEXT_CN				"Y-"
#define AXIS_Z_ADD_TEXT_CN				"Z+"
#define AXIS_Z_DEC_TEXT_CN				"Z-"
#define TEXT_01MM_CN					"0.1mm"
#define TEXT_1MM_CN						"1mm"
#define TEXT_10MM_CN					"10mm"

#define HOME_X_TEXT_CN						"X"
#define HOME_Y_TEXT_CN						"Y"
#define HOME_Z_TEXT_CN						"Z"
#define HOME_ALL_TEXT_CN					"回零"

#define PAGE_UP_TEXT_CN				"上一页"
#define PAGE_DOWN_TEXT_CN			"下一页"

#define EXTRUDER_IN_TEXT_CN		"进料"
#define EXTRUDER_OUT_TEXT_CN		"退料"
#define EXTRUDE_1MM_TEXT_CN			"1mm"
#define EXTRUDE_5MM_TEXT_CN			"5mm"
#define EXTRUDE_10MM_TEXT_CN		"10mm"
#define EXTRUDE_LOW_SPEED_TEXT_CN		"低速"
#define EXTRUDE_MEDIUM_SPEED_TEXT_CN	"常速"
#define EXTRUDE_HIGH_SPEED_TEXT_CN		"高速"

#define LEVELING_POINT1_TEXT_CN				"第一点"
#define LEVELING_POINT2_TEXT_CN				"第二点"
#define LEVELING_POINT3_TEXT_CN				"第三点"
#define LEVELING_POINT4_TEXT_CN				"第四点"
#define LEVELING_POINT5_TEXT_CN				"第五点"

#define FILESYS_TEXT_CN						"文件系统"
#define WIFI_TEXT_CN						"WIFI"
#define FAN_TEXT_CN							"风扇"
#define ABOUT_TEXT_CN						"关于"
#define BREAK_POINT_TEXT_CN					"断点续打"
#define FILAMENT_TEXT_CN					"换料"
#define LANGUAGE_TEXT_CN					"语言"
#define MOTOR_OFF_TEXT_CN					"关闭电机"
#define SHUTDOWN_TEXT_CN					"关机"

#define U_DISK_TEXT_CN						"U盘"
#define SD_CARD_TEXT_CN						"SD卡"
#define WIFI_NAME_TEXT_CN					"无线网络:"
#define WIFI_KEY_TEXT_CN					"密码:"
#define WIFI_IP_TEXT_CN						"IP:"
#define WIFI_AP_TEXT_CN						"状态: AP"
#define WIFI_STA_TEXT_CN					"状态: STA"
#define WIFI_CONNECTED_TEXT_CN				"已连接"
#define WIFI_DISCONNECTED_TEXT_CN			"未连接"
#define WIFI_EXCEPTION_TEXT_CN				"模块异常"
#define CLOUD_TEXT_CN						"云服务"
#define CLOUD_BIND_CN						"已绑定"
#define CLOUD_UNBIND_CN						"解绑"
#define CLOUD_UNBINDING_CN					"解绑中"
#define CLOUD_DISCONNECTED_CN				"未连接"
#define CLOUD_UNBINDED_CN					"未绑定"
#define CLOUD_BINDED_CN						"已绑定"
#define CLOUD_DISABLE_CN					"已禁用"

#define FAN_ADD_TEXT_CN						"增加"
#define FAN_DEC_TEXT_CN						"减少"
#define FAN_OPEN_TEXT_CN					"100%"
#define FAN_HALF_TEXT_CN					"50%"
#define FAN_CLOSE_TEXT_CN					"关闭"
#define FAN_TIPS1_TEXT_CN					"FAN"
#define FAN_TIPS2_TEXT_CN					"FAN\nClose"

#define FILAMENT_IN_TEXT_CN				"进料"
#define FILAMENT_OUT_TEXT_CN				"退料"
#define FILAMENT_EXT0_TEXT_CN				"喷头1"
#define FILAMENT_EXT1_TEXT_CN				"喷头2"
#define FILAMENT_HEAT_TEXT_CN				"预热"					
#define FILAMENT_STOP_TEXT_CN				"停止"
#define FILAMENT_CHANGE_TEXT_CN				"待打印机暂停后,\n请按<进料>或<退料>"
#define FILAMENT_DIALOG_LOAD_HEAT_TIPS_CN		"准备进料,正在加热,请稍等!"
#define FILAMENT_DIALOG_UNLOAD_HEAT_TIPS_CN		"准备退料,正在加热,请稍等!"
#define FILAMENT_DIALOG_LOAD_CONFIRM1_TIPS_CN           "加热完成,请装载耗材后,按<确定>开始进料!"
#define FILAMENT_DIALOG_LOAD_CONFIRM2_TIPS_CN           "请装载耗材,按<确定>开始进料!"
#define FILAMENT_DIALOG_UNLOAD_CONFIRM_TIPS_CN          "加热完成,请按<确定>开始退料!"
#define FILAMENT_DIALOG_LOADING_TIPS_CN                 "正在进料,请等待耗材加载完成!"
#define FILAMENT_DIALOG_UNLOADING_TIPS_CN               "正在退料,请等待耗材卸载完成!"
#define FILAMENT_DIALOG_LOAD_COMPLETE_TIPS_CN           "进料完成,请按<确定>返回"
#define FILAMENT_DIALOG_UNLOAD_COMPLETE_TIPS_CN         "退料完成,请按<确定>返回"
#define FILAMENT_DIALOG_EMPTY_TIPS_CN                   "没有打印材料!"

#define FILAMENT_TIPS3_TEXT_CN				"正在进料"
#define FILAMENT_TIPS4_TEXT_CN				"正在退料"
#define FILAMENT_TIPS5_TEXT_CN				"温度太低,请先预热"
#define FILAMENT_TIPS6_TEXT_CN				"换料完成"

#define PRE_HEAT_EXT_TEXT_CN				"喷头"
#define PRE_HEAT_BED_TEXT_CN				"热床"

#define FILE_LOADING_CN					"正在载入......"
#define NO_FILE_AND_CHECK_CN			"无文件!请检查文件系统设置!"
#define NO_FILE_CN					    "无文件!"

#define EXTRUDER_TEMP_TEXT_CN				"温度"
#define EXTRUDER_E_LENGTH1_TEXT_CN          "喷头"
#define EXTRUDER_E_LENGTH2_TEXT_CN          "喷头"
#define EXTRUDER_E_LENGTH3_TEXT_CN          "喷头"

#define ABOUT_TYPE_TEXT_CN					"TYPE: MKS Robin"
#define ABOUT_VERSION_TEXT_CN				"VERSION: 2.0.4"
#define ABOUT_WIFI_TEXT_CN					"WIFI:"

#define PRINTING_OPERATION_CN				"操作"
#define PRINTING_PAUSE_CN					"暂停"
#define PRINTING_TEMP_CN					"温度"
#define PRINTING_CHANGESPEED_CN			    "变速"
#define PRINTING_RESUME_CN					"恢复"
#define PRINTING_STOP_CN					"停止"
#define PRINTING_MORE_CN					"更多"
#define PRINTING_EXTRUDER_CN				"挤出"
#define PRINTING_MOVE_CN					"移动"

#define EXTRUDER_SPEED_CN					"挤出"
#define MOVE_SPEED_CN						"移动"
#define EXTRUDER_SPEED_STATE_CN			    "挤出速度"
#define MOVE_SPEED_STATE_CN					"移动速度"
#define STEP_1PERCENT_CN					"1%"
#define STEP_5PERCENT_CN					"5%"
#define STEP_10PERCENT_CN					"10%"

#define TITLE_READYPRINT_CN						"准备打印"
#define TITLE_PREHEAT_CN						"预热"
#define TITLE_MOVE_CN					        "移动"
#define TITLE_HOME_CN							"回零"
#define TITLE_EXTRUDE_CN						"挤出"
#define TITLE_LEVELING_CN						"调平"
#define TITLE_SET_CN							"设置"
#define TITLE_MORE_CN							"更多"
#define TITLE_CHOOSEFILE_CN						"选择文件"
#define TITLE_PRINTING_CN						"正在打印"
#define TITLE_OPERATION_CN						"操作"
#define TITLE_ADJUST_CN							"调整"
#define	TITLE_WIRELESS_CN						"无线网络"
#define	TITLE_FILAMENT_CN						"换料"
#define TITLE_ABOUT_CN							"关于"
#define TITLE_FAN_CN							"风扇"
#define TITLE_LANGUAGE_CN						"语言"
#define TITLE_PAUSE_CN							"暂停"
#define TITLE_CHANGESPEED_CN				    "变速"
#define TITLE_CLOUD_TEXT_CN				        "云服务"
#define TITLE_DIALOG_CONFIRM_CN				"确认"
#define TITLE_FILESYS_CN								"文件系统"

#define AUTO_SHUTDOWN_CN					"自动关机"
#define MANUAL_SHUTDOWN_CN					"手动关机"

#define DIALOG_CONFIRM_CN					"确定"
#define DIALOG_CANCLE_CN					"取消"
#define DIALOG_OK_CN						"确认"
#define DIALOG_RESET_CN						"重置"
#define DIALOG_DISABLE_CN					"禁用"
#define DIALOG_PRINT_MODEL_CN			    "打印模型?"
#define DIALOG_CANCEL_PRINT_CN		        "停止打印?"
#define DIALOG_RETRY_CN						"重试"
#define DIALOG_STOP_CN						"停止"
#define DIALOG_REPRINT_FROM_BREAKPOINT_CN	"从断点续打?"
#define DIALOG_UNBIND_PRINTER_CN			"解除绑定 ?"
#define DIALOG_ERROR_TIPS1_CN				"错误:找不到文件,请插入sd卡/u盘!"
#define DIALOG_ERROR_TIPS2_CN				"错误:通信失败,请检查波特率或主板硬件!"
#define DIALOG_ERROR_TIPS3_CN				"错误:文件名或文件路径太长 !"
#define DIALOG_CLOSE_MACHINE_CN             "正在关机......"
#define DIALOG_UNBIND_PRINTER_CN            "解除绑定?"
#define DIALOG_WIFI_ENABLE_CN            "使能"
#define DIALOG_WIFI_DISABLE_CN           "禁用"
#define DIALOG_TEXT_WIFI_ENABLE_CN       "已使能"
#define DIALOG_TEXT_WIFI_DISABLE_CN      "已禁用"  

#define DIALOG_TEXT_NO_TEMP_TIPS_CN  "没有目标温度,请选择默认温度或设置温度"
#define DIALOG_TEXT_DEFAULT_TEMP_CN  "默认温度"
#define DIALOG_TEXT_SETTING_TEMP_CN  "设置温度"
//***************繁体中文**********************//
#define TOOL_TEXT_T_CN							"工具"
#define PREHEAT_TEXT_T_CN 					    "預熱"
#define	MOVE_TEXT_T_CN							"移動"
#define HOME_TEXT_T_CN  						"回零"
#define PRINT_TEXT_T_CN							"打印"
#define EXTRUDE_TEXT_T_CN 					    "擠出"
#define LEVELING_TEXT_T_CN 					    "調平"
#define AUTO_LEVELING_TEXT_T_CN 		        "自動調平"
#define SET_TEXT_T_CN							"設置"
#define MORE_TEXT_T_CN     					    "更多"

#define ADD_TEXT_T_CN			    "增加"
#define DEC_TEXT_T_CN			    "減少"
#define EXTRUDER_1_TEXT_T_CN		"噴頭1"
#define EXTRUDER_2_TEXT_T_CN		"噴頭2"
#define HEATBED_TEXT_T_CN			"熱床"
#define TEXT_1C_T_CN				"1℃"
#define TEXT_5C_T_CN				"5℃"
#define TEXT_10C_T_CN				"10℃"
#define CLOSE_TEXT_T_CN				"關閉"

#define BACK_TEXT_T_CN					    "返回"

#define AXIS_X_ADD_TEXT_T_CN				"X+"
#define AXIS_X_DEC_TEXT_T_CN				"X-"
#define AXIS_Y_ADD_TEXT_T_CN				"Y+"
#define AXIS_Y_DEC_TEXT_T_CN				"Y-"
#define AXIS_Z_ADD_TEXT_T_CN				"Z+"
#define AXIS_Z_DEC_TEXT_T_CN				"Z-"
#define TEXT_01MM_T_CN						"0.1mm"
#define TEXT_1MM_T_CN						"1mm"
#define TEXT_10MM_T_CN						"10mm"

#define HOME_X_TEXT_T_CN					"X"
#define HOME_Y_TEXT_T_CN					"Y"
#define HOME_Z_TEXT_T_CN					"Z"
#define HOME_ALL_TEXT_T_CN					"回零"

#define PAGE_UP_TEXT_T_CN					"上一頁"
#define PAGE_DOWN_TEXT_T_CN				    "下一頁"

#define EXTRUDER_IN_TEXT_T_CN		    "進料"
#define EXTRUDER_OUT_TEXT_T_CN		    "退料"
#define EXTRUDE_1MM_TEXT_T_CN			"1mm"
#define EXTRUDE_5MM_TEXT_T_CN			"5mm"
#define EXTRUDE_10MM_TEXT_T_CN		    "10mm"
#define EXTRUDE_LOW_SPEED_TEXT_T_CN		"低速"
#define EXTRUDE_MEDIUM_SPEED_TEXT_T_CN	"常速"
#define EXTRUDE_HIGH_SPEED_TEXT_T_CN	"高速"

#define LEVELING_POINT1_TEXT_T_CN				"第一點"
#define LEVELING_POINT2_TEXT_T_CN				"第二點"
#define LEVELING_POINT3_TEXT_T_CN				"第三點"
#define LEVELING_POINT4_TEXT_T_CN				"第四點"
#define LEVELING_POINT5_TEXT_T_CN				"第五點"

#define FILESYS_TEXT_T_CN							"文件系統"
#define WIFI_TEXT_T_CN								"WIFI"
#define FAN_TEXT_T_CN								"風扇"
#define ABOUT_TEXT_T_CN								"關於"
#define BREAK_POINT_TEXT_T_CN						"斷點續打"
#define FILAMENT_TEXT_T_CN							"換料"
#define LANGUAGE_TEXT_T_CN							"語言"
#define MOTOR_OFF_TEXT_T_CN							"關閉電機"
#define SHUTDOWN_TEXT_T_CN							"關機"

#define U_DISK_TEXT_T_CN							"U盤"
#define SD_CARD_TEXT_T_CN							"SD卡"
#define WIFI_NAME_TEXT_T_CN							"無線網絡:"
#define WIFI_KEY_TEXT_T_CN							"密碼:"
#define WIFI_IP_TEXT_T_CN							"IP:"
#define WIFI_AP_TEXT_T_CN							"狀態: AP"
#define WIFI_STA_TEXT_T_CN							"狀態: STA"
#define WIFI_CONNECTED_TEXT_T_CN				    "已連接"
#define WIFI_DISCONNECTED_TEXT_T_CN			        "未連接"
#define WIFI_EXCEPTION_TEXT_T_CN				    "模塊異常"
#define CLOUD_TEXT_T_CN								"雲服務"
#define CLOUD_BIND_T_CN								"已綁定"
#define CLOUD_UNBIND_T_CN							"解綁"
#define CLOUD_UNBINDING_T_CN					    "解绑中"
#define CLOUD_DISCONNECTED_T_CN				        "未連接"
#define CLOUD_UNBINDED_T_CN						    "未綁定"
#define CLOUD_BINDED_T_CN							"已綁定"
#define CLOUD_DISABLE_T_CN						    "已禁用"

#define FAN_ADD_TEXT_T_CN							"增加"
#define FAN_DEC_TEXT_T_CN							"減少"
#define FAN_OPEN_TEXT_T_CN							"100%"
#define FAN_HALF_TEXT_T_CN							"50%"
#define FAN_CLOSE_TEXT_T_CN							"關閉"
#define FAN_TIPS1_TEXT_T_CN							"FAN"
#define FAN_TIPS2_TEXT_T_CN							"FAN\nClose"

#define FILAMENT_IN_TEXT_T_CN					"進料"
#define FILAMENT_OUT_TEXT_T_CN					"退料"
#define FILAMENT_EXT0_TEXT_T_CN					"噴頭1"
#define FILAMENT_EXT1_TEXT_T_CN					"噴頭2"
#define FILAMENT_HEAT_TEXT_T_CN					"預熱"					
#define FILAMENT_STOP_TEXT_T_CN					"停止"
#define FILAMENT_CHANGE_TEXT_T_CN				"準備換料"
#define FILAMENT_TIPS2_TEXT_T_CN				"T:"
#define FILAMENT_TIPS3_TEXT_T_CN				"正在進料"
#define FILAMENT_TIPS4_TEXT_T_CN				"正在退料"
#define FILAMENT_TIPS5_TEXT_T_CN				"溫度太低,請先預熱"
#define FILAMENT_TIPS6_TEXT_T_CN				"換料完成"

#define FILAMENT_CHANGE_TEXT_T_CN				"待打印機暫停后,\n請按<進料>或<退料>"
#define FILAMENT_DIALOG_LOAD_HEAT_TIPS_T_CN		"準備進料,正在加熱,請稍等"
#define FILAMENT_DIALOG_UNLOAD_HEAT_TIPS_T_CN		"準備退料,正在加熱,請稍等"
#define FILAMENT_DIALOG_LOAD_CONFIRM1_TIPS_T_CN           "加熱完成,請裝載耗材后,按<確定>開始進料"
#define FILAMENT_DIALOG_LOAD_CONFIRM2_TIPS_T_CN           "請裝載耗,按<確定>開始進料!"
#define FILAMENT_DIALOG_UNLOAD_CONFIRM_TIPS_T_CN          "加熱完成,请按<確定>開始退料!"
#define FILAMENT_DIALOG_LOADING_TIPS_T_CN                 "正在進料,请等待耗材加載完成!"
#define FILAMENT_DIALOG_UNLOADING_TIPS_T_CN               "正在退料,请等待耗材卸載完成!"
#define FILAMENT_DIALOG_LOAD_COMPLETE_TIPS_T_CN           "進料完成,请按<確定>返回"
#define FILAMENT_DIALOG_UNLOAD_COMPLETE_TIPS_T_CN         "退料完成,请按<確定>返回"
#define FILAMENT_DIALOG_EMPTY_TIPS_T_CN                   "没有打印材料!"

#define PRE_HEAT_EXT_TEXT_T_CN					"噴頭"
#define PRE_HEAT_BED_TEXT_T_CN					"熱床"

#define FILE_LOADING_T_CN					"正在載入......"
#define NO_FILE_AND_CHECK_T_CN					"無文件!請檢查文件系統設置!"
#define NO_FILE_T_CN					"無文件!"

#define EXTRUDER_TEMP_TEXT_T_CN		    "溫度:"
#define EXTRUDER_E_LENGTH1_TEXT_T_CN    "噴頭"
#define EXTRUDER_E_LENGTH2_TEXT_T_CN    "噴頭"
#define EXTRUDER_E_LENGTH3_TEXT_T_CN    "噴頭"

#define ABOUT_TYPE_TEXT_T_CN			"TYPE: MKS TFT"
#define ABOUT_VERSION_TEXT_T_CN			"VERSION: 3.0.0"
#define ABOUT_WIFI_TEXT_T_CN			"WIFI:"

#define PRINTING_OPERATION_T_CN		    "操作"
#define PRINTING_PAUSE_T_CN				"暫停"
#define PRINTING_TEMP_T_CN				"溫度"
#define PRINTING_CHANGESPEED_T_CN		"變速"
#define PRINTING_RESUME_T_CN			"恢復"
#define PRINTING_STOP_T_CN				"停止"
#define PRINTING_MORE_T_CN				"更多"
#define PRINTING_EXTRUDER_T_CN			"擠出"
#define PRINTING_MOVE_T_CN              "移動"

#define EXTRUDER_SPEED_T_CN				"擠出"
#define MOVE_SPEED_T_CN					"移動"
#define EXTRUDER_SPEED_STATE_T_CN		"擠出速度"
#define MOVE_SPEED_STATE_T_CN			"移動速度"
#define STEP_1PERCENT_T_CN				"1%%"
#define STEP_5PERCENT_T_CN				"5%%"
#define STEP_10PERCENT_T_CN				"10%%"

#define TITLE_READYPRINT_T_CN				    "準備打印"
#define TITLE_PREHEAT_T_CN						"預熱"
#define TITLE_MOVE_T_CN					        "移動"
#define TITLE_HOME_T_CN							"回零"
#define TITLE_EXTRUDE_T_CN						"擠出"
#define TITLE_LEVELING_T_CN						"調平"
#define TITLE_SET_T_CN							"設置"
#define TITLE_MORE_T_CN							"更多"
#define TITLE_CHOOSEFILE_T_CN					"選擇文件"
#define TITLE_PRINTING_T_CN						"正在打印"
#define TITLE_OPERATION_T_CN					"操作"
#define TITLE_ADJUST_T_CN						"調整"
#define	TITLE_WIRELESS_T_CN						"無線網絡"
#define	TITLE_FILAMENT_T_CN						"換料"
#define TITLE_ABOUT_T_CN						"關於"
#define TITLE_FAN_T_CN							"風扇"
#define TITLE_LANGUAGE_T_CN						"語言"
#define TITLE_PAUSE_T_CN						"暫停"
#define TITLE_CHANGESPEED_T_CN				    "變速"
#define TITLE_CLOUD_TEXT_T_CN				        "雲服務"
#define TITLE_DIALOG_CONFIRM_T_CN					"確認"
#define TITLE_FILESYS_T_CN								"文件系統"


#define AUTO_SHUTDOWN_T_CN				"自動關機"
#define MANUAL_SHUTDOWN_T_CN			"手動關機"

#define DIALOG_CONFIRM_T_CN				"確定"
#define DIALOG_CANCLE_T_CN				"取消"
#define DIALOG_OK_T_CN					"確認"
#define DIALOG_RESET_T_CN				"重設"
#define DIALOG_RETRY_T_CN				"重試"
#define DIALOG_DISABLE_T_CN				"禁用"
#define DIALOG_PRINT_MODEL_T_CN			"打印模型?"
#define DIALOG_CANCEL_PRINT_T_CN		"停止打印?"
#define DIALOG_RETRY_T_CN									"重試"
#define DIALOG_STOP_T_CN									"停止"
#define DIALOG_REPRINT_FROM_BREAKPOINT_T_CN	                "從斷點續打?"
#define DIALOG_UNBIND_PRINTER_T_CN						    "解除綁定?"
#define DIALOG_ERROR_TIPS1_T_CN								"錯誤:找不到文件,請插入sd卡/u盤!"
#define DIALOG_ERROR_TIPS2_T_CN								"錯誤:通信失敗,請檢查波特率或主板硬件!"
#define DIALOG_ERROR_TIPS3_T_CN								"錯誤:文件名或文件路徑太長!"
#define DIALOG_CLOSE_MACHINE_T_CN             "正在關機......"
#define DIALOG_UNBIND_PRINTER_T_CN            "解除綁定?"
#define DIALOG_WIFI_ENABLE_T_CN            "使能"
#define DIALOG_WIFI_DISABLE_T_CN           "禁用"
#define DIALOG_TEXT_WIFI_ENABLE_T_CN       "已使能"
#define DIALOG_TEXT_WIFI_DISABLE_T_CN      "已禁用"

#define DIALOG_TEXT_NO_TEMP_TIPS_T_CN  "没有目標溫度,請選擇默認溫度或設置溫度"
#define DIALOG_TEXT_DEFAULT_TEMP_T_CN  "默認溫度"
#define DIALOG_TEXT_SETTING_TEMP_T_CN  "設置溫度"
//****************英文***************************//
#define TOOL_TEXT_EN		    "Tool"
#define PREHEAT_TEXT_EN         "Preheat"
#define	MOVE_TEXT_EN		    "Move"
#define HOME_TEXT_EN            "Home"
#define PRINT_TEXT_EN		    "Printing"
#define EXTRUDE_TEXT_EN         "Extrusion"
#define LEVELING_TEXT_EN        "Leveling"
#define AUTO_LEVELING_TEXT_EN   "AutoLevel"
#define SET_TEXT_EN			    "Settings"
#define MORE_TEXT_EN            "More"

#define ADD_TEXT_EN			    "Add"
#define DEC_TEXT_EN			    "Dec"
#define EXTRUDER_1_TEXT_EN		"Extruder1"
#define EXTRUDER_2_TEXT_EN		"Extruder2"
#define HEATBED_TEXT_EN			"HeatBed"
#define TEXT_1C_EN				"1℃"
#define TEXT_5C_EN				"5℃"
#define TEXT_10C_EN				"10℃"
#define CLOSE_TEXT_EN			"Close"

#define BACK_TEXT_EN				    "Back"

#define AXIS_X_ADD_TEXT_EN				"X+"
#define AXIS_X_DEC_TEXT_EN				"X-"
#define AXIS_Y_ADD_TEXT_EN				"Y+"
#define AXIS_Y_DEC_TEXT_EN				"Y-"
#define AXIS_Z_ADD_TEXT_EN				"Z+"
#define AXIS_Z_DEC_TEXT_EN				"Z-"
#define TEXT_01MM_EN					"0.1mm"
#define TEXT_1MM_EN						"1mm"
#define TEXT_10MM_EN					"10mm"

#define HOME_X_TEXT_EN					"X"
#define HOME_Y_TEXT_EN					"Y"
#define HOME_Z_TEXT_EN					"Z"
#define HOME_ALL_TEXT_EN				"Home"

#define PAGE_UP_TEXT_EN					"Page up"
#define PAGE_DOWN_TEXT_EN				"Page down"

#define EXTRUDER_IN_TEXT_EN		"In"
#define EXTRUDER_OUT_TEXT_EN		"Out"
#define EXTRUDE_1MM_TEXT_EN			"1mm"
#define EXTRUDE_5MM_TEXT_EN			"5mm"
#define EXTRUDE_10MM_TEXT_EN		"10mm"
#define EXTRUDE_LOW_SPEED_TEXT_EN		"Low"
#define EXTRUDE_MEDIUM_SPEED_TEXT_EN	"Normal"
#define EXTRUDE_HIGH_SPEED_TEXT_EN		"High"

#define LEVELING_POINT1_TEXT_EN				"Point1"
#define LEVELING_POINT2_TEXT_EN				"Point2"
#define LEVELING_POINT3_TEXT_EN				"Point3"
#define LEVELING_POINT4_TEXT_EN				"Point4"
#define LEVELING_POINT5_TEXT_EN				"Point5"

#define FILESYS_TEXT_EN								"FileSys"
#define WIFI_TEXT_EN								"WiFi"
#define FAN_TEXT_EN									"Fan"
#define ABOUT_TEXT_EN								"About"
#define BREAK_POINT_TEXT_EN						    "Continue"
#define FILAMENT_TEXT_EN							"Filament"
#define LANGUAGE_TEXT_EN							"Language"
#define MOTOR_OFF_TEXT_EN							"Motor-off"
#define SHUTDOWN_TEXT_EN							"Shutdown"

#define U_DISK_TEXT_EN								"USB"
#define SD_CARD_TEXT_EN								"SD"
#define WIFI_NAME_TEXT_EN							"WiFi:"
#define WIFI_KEY_TEXT_EN							"Key:"
#define WIFI_IP_TEXT_EN								"IP:"
#define WIFI_AP_TEXT_EN								"State: AP"
#define WIFI_STA_TEXT_EN							"State: STA"
#define WIFI_CONNECTED_TEXT_EN				        "Connected"
#define WIFI_DISCONNECTED_TEXT_EN			        "Disconnected"
#define WIFI_EXCEPTION_TEXT_EN				        "Exception"
#define CLOUD_TEXT_EN								"Cloud"
#define CLOUD_BIND_EN								"Bind"
#define CLOUD_UNBIND_EN							    "Unbind"
#define CLOUD_UNBINDING_EN					        "Unbinding"
#define CLOUD_DISCONNECTED_EN				        "Disconnected"
#define CLOUD_UNBINDED_EN						    "Unbinded"
#define CLOUD_BINDED_EN							    "Binded"
#define CLOUD_DISABLE_EN						    "Disable"

#define FAN_ADD_TEXT_EN								"Add"
#define FAN_DEC_TEXT_EN								"Dec"
#define FAN_OPEN_TEXT_EN							"100%"
#define FAN_HALF_TEXT_EN							"50%"
#define FAN_CLOSE_TEXT_EN							"Close"
#define FAN_TIPS1_TEXT_EN							"Fan Speed"
#define FAN_TIPS2_TEXT_EN							"Fan Speed\nClose"

#define FILAMENT_IN_TEXT_EN				"Load"
#define FILAMENT_OUT_TEXT_EN				"Unload"
#define FILAMENT_EXT0_TEXT_EN				"E1"
#define FILAMENT_EXT1_TEXT_EN				"E2"
#define FILAMENT_HEAT_TEXT_EN				"Preheat"					
#define FILAMENT_STOP_TEXT_EN				"Stop"
#define FILAMENT_CHANGE_TEXT_EN				"Filament replace"
#define FILAMENT_TIPS2_TEXT_EN				"T:"
#define FILAMENT_TIPS3_TEXT_EN				"Loading..."
#define FILAMENT_TIPS4_TEXT_EN				"Unloading..."
#define FILAMENT_TIPS5_TEXT_EN				"Temp is too low to go,please heat"
#define FILAMENT_TIPS6_TEXT_EN				"Completed"

#define FILAMENT_CHANGE_TEXT_EN				"Please click load \nor unload."
#define FILAMENT_DIALOG_LOAD_HEAT_TIPS_EN		"Heating up the nozzle,please wait..."
#define FILAMENT_DIALOG_UNLOAD_HEAT_TIPS_EN		"Heating up the nozzle,please wait..."
#define FILAMENT_DIALOG_LOAD_CONFIRM1_TIPS_EN           "Heat completed,please load filament \nto extruder,and click confirm \nfor start loading."
#define FILAMENT_DIALOG_LOAD_CONFIRM2_TIPS_EN           "Please load filament to extruder,\nand click confirm for start loading."
#define FILAMENT_DIALOG_UNLOAD_CONFIRM_TIPS_EN          "Heat completed,please \nclick confirm for start unloading.!"
#define FILAMENT_DIALOG_LOADING_TIPS_EN                 "Is loading ,please wait!"
#define FILAMENT_DIALOG_UNLOADING_TIPS_EN               "Is unloading,please wait!"
#define FILAMENT_DIALOG_LOAD_COMPLETE_TIPS_EN           "Load filament completed,\nclick confirm for return!"
#define FILAMENT_DIALOG_UNLOAD_COMPLETE_TIPS_EN         "Unload filament completed,\nclick confirm for return!"
#define FILAMENT_DIALOG_EMPTY_TIPS_EN                   "filament detection switch is no pressed!"

#define PRE_HEAT_EXT_TEXT_EN				"E"
#define PRE_HEAT_BED_TEXT_EN				"Bed"

#define FILE_LOADING_EN					"Loading......"
#define NO_FILE_AND_CHECK_EN					"No files found!\n   Check the file system configuration!"
#define NO_FILE_EN					"No files found!"

#define EXTRUDER_TEMP_TEXT_EN				"T:"
#define EXTRUDER_E_LENGTH1_TEXT_EN   "E"
#define EXTRUDER_E_LENGTH2_TEXT_EN   "E"
#define EXTRUDER_E_LENGTH3_TEXT_EN   "E"

#define ABOUT_TYPE_TEXT_EN					    "Type: MKS TFT"
#define ABOUT_VERSION_TEXT_EN					"Version: 3.0.0"
#define ABOUT_WIFI_TEXT_EN						"WIFI:"

#define PRINTING_OPERATION_EN					"Option"
#define PRINTING_PAUSE_EN						"Pause"
#define PRINTING_TEMP_EN						"Temp."
#define PRINTING_CHANGESPEED_EN				    "Speed"
#define PRINTING_RESUME_EN						"Resume"
#define PRINTING_STOP_EN						"Stop"
#define PRINTING_MORE_EN						"More"
#define PRINTING_EXTRUDER_EN					"Extrusion"
#define PRINTING_MOVE_EN						"Move"

#define EXTRUDER_SPEED_EN						"Extrusion"
#define MOVE_SPEED_EN							"Move"
#define EXTRUDER_SPEED_STATE_EN					"Extrude Speed"
#define MOVE_SPEED_STATE_EN						"Move Speed"
#define STEP_1PERCENT_EN						"1%"
#define STEP_5PERCENT_EN						"5%"
#define STEP_10PERCENT_EN						"10%"

#define TITLE_READYPRINT_EN						"ReadyPrint"
#define TITLE_PREHEAT_EN						"Preheat"
#define TITLE_MOVE_EN					        "Move"
#define TITLE_HOME_EN							"Home"
#define TITLE_EXTRUDE_EN						"Extrusion"
#define TITLE_LEVELING_EN						"Leveling"
#define TITLE_SET_EN							"Settings"
#define TITLE_MORE_EN							"More"
#define TITLE_CHOOSEFILE_EN						"ChooseFile"
#define TITLE_PRINTING_EN						"Printing"
#define TITLE_OPERATION_EN						"Operation"
#define TITLE_ADJUST_EN							"Adjust"
#define	TITLE_WIRELESS_EN						"Wireless"
#define	TITLE_FILAMENT_EN						"Filament"
#define TITLE_ABOUT_EN							"About"
#define TITLE_FAN_EN							"Fan"
#define TITLE_LANGUAGE_EN						"Language"
#define TITLE_PAUSE_EN							"Pause"
#define TITLE_CHANGESPEED_EN				    "Speed"
#define TITLE_CLOUD_TEXT_EN				        "Cloud"
#define TITLE_DIALOG_CONFIRM_EN				"Confirm"
#define TITLE_FILESYS_EN								"FileSys"

#define AUTO_SHUTDOWN_EN						"Auto"
#define MANUAL_SHUTDOWN_EN						"Manual"

#define DIALOG_CONFIRM_EN							"Confirm"
#define DIALOG_CANCLE_EN							"Cancel"
#define DIALOG_OK_EN								"OK"
#define DIALOG_RESET_EN								"Reset"
#define DIALOG_RETRY_EN								"Retry"
#define DIALOG_DISABLE_EN							"Disable"
#define DIALOG_PRINT_MODEL_EN				        "Print this model?"
#define DIALOG_CANCEL_PRINT_EN				        "Stop print?"
#define DIALOG_RETRY_EN								"Retry"
#define DIALOG_STOP_EN								"Stop"
#define DIALOG_REPRINT_FROM_BREAKPOINT_EN	        "Reprint from breakpoint?"
#define DIALOG_UNBIND_PRINTER_EN					"Unbind the printer?"
#define DIALOG_ERROR_TIPS1_EN						"Error:no file,please check it again."
#define DIALOG_ERROR_TIPS2_EN						"Error:transaction failed.please check display baudrate \nwhether as the same as mainboard!"
#define DIALOG_ERROR_TIPS3_EN		        "Error:file name or path is too long!"
#define DIALOG_CLOSE_MACHINE_EN             "Closing machine......"
#define DIALOG_UNBIND_PRINTER_EN            "Unbind the printer?"
#define DIALOG_WIFI_ENABLE_EN            "Enable"
#define DIALOG_WIFI_DISABLE_EN           "Disable"
#define DIALOG_TEXT_WIFI_ENABLE_EN       "Enable"
#define DIALOG_TEXT_WIFI_DISABLE_EN      "Disable"

#define DIALOG_TEXT_NO_TEMP_TIPS_EN     "No target temperature, \nplease choose the default temperature \nor set the temperature"
#define DIALOG_TEXT_DEFAULT_TEMP_EN     "Default"
#define DIALOG_TEXT_SETTING_TEMP_EN     "Setting"
//****************日文*************************//
#define TOOL_TEXT_JP		"ツール"
#define PREHEAT_TEXT_JP     "予熱"
#define	MOVE_TEXT_JP		"モバイル"
#define HOME_TEXT_JP        "ゼロ"
#define PRINT_TEXT_JP		"プリント"
#define EXTRUDE_TEXT_JP     "押出"
#define LEVELING_TEXT_JP    "レベリング"
#define AUTO_LEVELING_TEXT_JP   "オートレベリング"
#define SET_TEXT_JP			    "セット\nアップ"
#define MORE_TEXT_JP            "もっと"

#define ADD_TEXT_JP			    "さらに"
#define DEC_TEXT_JP			    "リダクション"
#define EXTRUDER_1_TEXT_JP	    "シャワーノズル1"
#define EXTRUDER_2_TEXT_JP		"シャワーノズル1"
#define HEATBED_TEXT_JP			"ホットベッド"
#define TEXT_1C_JP				"1℃"
#define TEXT_5C_JP				"5℃"
#define TEXT_10C_JP				"10℃"
#define CLOSE_TEXT_JP			"クローズ"

#define BACK_TEXT_JP					"リターン"

#define AXIS_X_ADD_TEXT_JP				"X+"
#define AXIS_X_DEC_TEXT_JP				"X-"
#define AXIS_Y_ADD_TEXT_JP				"Y+"
#define AXIS_Y_DEC_TEXT_JP				"Y-"
#define AXIS_Z_ADD_TEXT_JP				"Z+"
#define AXIS_Z_DEC_TEXT_JP				"Z-"
#define TEXT_01MM_JP					"0.1mm"
#define TEXT_1MM_JP						"1mm"
#define TEXT_10MM_JP					"10mm"

#define HOME_X_TEXT_JP					"X"
#define HOME_Y_TEXT_JP					"Y"
#define HOME_Z_TEXT_JP					"Z"
#define HOME_ALL_TEXT_JP				"ゼロ"

#define PAGE_UP_TEXT_JP					"前のページ"
#define PAGE_DOWN_TEXT_JP				"下一ページ"

#define EXTRUDER_IN_TEXT_JP		    "フィード"
#define EXTRUDER_OUT_TEXT_JP		    "OUT"
#define EXTRUDE_1MM_TEXT_JP			    "1mm"
#define EXTRUDE_5MM_TEXT_JP			    "5mm"
#define EXTRUDE_10MM_TEXT_JP		    "10mm"
#define EXTRUDE_LOW_SPEED_TEXT_JP		"LOW"
#define EXTRUDE_MEDIUM_SPEED_TEXT_JP	"Medium"
#define EXTRUDE_HIGH_SPEED_TEXT_JP		"High"

#define LEVELING_POINT1_TEXT_JP				"Point1"
#define LEVELING_POINT2_TEXT_JP				"Point2"
#define LEVELING_POINT3_TEXT_JP			    "Point3"
#define LEVELING_POINT4_TEXT_JP				"Point4"
#define LEVELING_POINT5_TEXT_JP				"Point5"

#define FILESYS_TEXT_JP							    "FileSys"
#define WIFI_TEXT_JP							    "WIFI"
#define FAN_TEXT_JP								    "Fan"
#define ABOUT_TEXT_JP							    "About"
#define BREAK_POINT_TEXT_JP						    "Continue"
#define FILAMENT_TEXT_JP							"Filament"
#define LANGUAGE_TEXT_JP							"Language"
#define MOTO_OFF_TEXT_JP							"Moto-off"
#define SHUTDOWN_TEXT_JP							"Shutdown"

#define U_DISK_TEXT_JP								"U Disk"
#define SD_CARD_TEXT_JP								"SDCard"
#define WIFI_NAME_TEXT_JP							"WIFI:%s"
#define WIFI_KEY_TEXT_JP							"KEY:%s"
#define WIFI_IP_TEXT_JP								"IP:%s"
#define WIFI_AP_TEXT_JP								"STATE: AP"
#define WIFI_STA_TEXT_JP							"STATE: STA"
#define WIFI_CONNECTED_TEXT_JP				        "CONNECTED"
#define WIFI_DISCONNECTED_TEXT_JP			        "DISCONNECTED"
#define WIFI_EXCEPTION_TEXT_JP				        "EXCEPTION"
#define CLOUD_TEXT_JP								"Cloud"
#define CLOUD_BIND_JP								"Bind"
#define CLOUD_UNBIND_JP							    "Unbind"
#define CLOUD_UNBINDING_JP					        "Unbinding"
#define CLOUD_DISCONNECTED_JP				        "Disconnected"
#define CLOUD_UNBINDED_JP					        "Unbinded"
#define CLOUD_BINDED_JP						        "Binded"
#define CLOUD_DISABLE_JP						    "Disable"

#define FAN_ADD_TEXT_JP								"ADD"
#define FAN_DEC_TEXT_JP								"DEC"
#define FAN_OPEN_TEXT_JP							"100%"
#define FAN_HALF_TEXT_JP							"50%"
#define FAN_CLOSE_TEXT_JP							"Close"
#define FAN_TIPS1_TEXT_JP							"FAN\n%d"
#define FAN_TIPS2_TEXT_JP							"FAN\nClose"

#define FILAMENT_IN_TEXT_JP					"In"
#define FILAMENT_OUT_TEXT_JP				"Out"
#define FILAMENT_EXT0_TEXT_JP				"E1"
#define FILAMENT_EXT1_TEXT_JP				"E2"
#define FILAMENT_HEAT_TEXT_JP				"Preheat"					
#define FILAMENT_STOP_TEXT_JP				"Stop"
#define FILAMENT_CHANGE_TEXT_JP				"Filament replace"
#define FILAMENT_TIPS2_TEXT_JP				"T:%d℃/%d℃"
#define FILAMENT_TIPS3_TEXT_JP				"loading..."
#define FILAMENT_TIPS4_TEXT_JP				"unloading..."
#define FILAMENT_TIPS5_TEXT_JP				"Temp is too low to go,please heat"
#define FILAMENT_TIPS6_TEXT_JP				"Completed"

#define FILAMENT_CHANGE_TEXT_JP				"Please click Load \nor unload."
#define FILAMENT_DIALOG_LOAD_HEAT_TIPS_JP		"Heating up the nozzle,please wait..."
#define FILAMENT_DIALOG_UNLOAD_HEAT_TIPS_JP		"Heating up the nozzle,please wait..."
#define FILAMENT_DIALOG_LOAD_CONFIRM1_TIPS_JP           "Heat completed,please load filament \nto extruder,and click confirm \nfor start loading."
#define FILAMENT_DIALOG_LOAD_CONFIRM2_TIPS_JP           "Please load filament to extruder,\nand click confirm for start loading."
#define FILAMENT_DIALOG_UNLOAD_CONFIRM_TIPS_JP          "Heat completed,please \nclick confirm for start unloading.!"
#define FILAMENT_DIALOG_LOADING_TIPS_JP                 "Is loading ,please wait!"
#define FILAMENT_DIALOG_UNLOADING_TIPS_JP               "Is unloading,please wait!"
#define FILAMENT_DIALOG_LOAD_COMPLETE_TIPS_JP           "Load filament completed,\nclick confirm for return!"
#define FILAMENT_DIALOG_UNLOAD_COMPLETE_TIPS_JP         "Unload filament completed,\nclick confirm for return!"

#define PRE_HEAT_EXT_TEXT_JP				"E%d\n%d℃/%d℃"
#define PRE_HEAT_BED_TEXT_JP				"Bed%d\n%d℃/%d℃"

#define FILE_LOADING_JP					"にロード......"
#define NO_FILE_AND_CHECK_JP					"いいえファイル!\nファイルシステムをチェックしてください!"
#define NO_FILE_JP					"いいえファイル!"

#define EXTRUDER_TEMP_TEXT_JP				"T:%d℃"
#define EXTRUDER_E_LENGTH1_TEXT_JP          "E%d:%dmm"
#define EXTRUDER_E_LENGTH2_TEXT_JP          "E%d:%dcm"
#define EXTRUDER_E_LENGTH3_TEXT_JP          "E%d:%dm"

#define ABOUT_TYPE_TEXT_JP					"TYPE: MKS TFT"
#define ABOUT_VERSION_TEXT_JP				"VERSION: 3.0.0"
#define ABOUT_WIFI_TEXT_JP					"WIFI:"

#define PRINTING_OPERATION_JP				"Operation"
#define PRINTING_PAUSE_JP					"Pause"
#define PRINTING_TEMP_JP					"Temp."
#define PRINTING_CHANGESPEED_JP				"Speed"
#define PRINTING_RESUME_JP					"Resume"
#define PRINTING_STOP_JP					"Stop"
#define PRINTING_MORE_JP					"More"
#define PRINTING_EXTRUDER_JP				"Extruder"
#define PRINTING_MOVE_JP                    "Move"

#define EXTRUDER_SPEED_JP					"Extrude"
#define MOVE_SPEED_JP						"Move"
#define EXTRUDER_SPEED_STATE_JP				"Extrude Speed"
#define MOVE_SPEED_STATE_JP					"Move Speed"
#define STEP_1PERCENT_JP					"1%"
#define STEP_5PERCENT_JP					"5%"
#define STEP_10PERCENT_JP					"10%"

#define TITLE_READYPRINT_JP						"ReadyPrint"
#define TITLE_PREHEAT_JP						"Preheat"
#define TITLE_MOVE_JP					        "Move"
#define TITLE_HOME_JP							"Home"
#define TITLE_EXTRUDE_JP						"Extrude"
#define TITLE_LEVELING_JP						"Leveling"
#define TITLE_SET_JP							"Set"
#define TITLE_MORE_JP							"More"
#define TITLE_CHOOSEFILE_JP						"ChooseFile"
#define TITLE_PRINTING_JP						"Printing"
#define TITLE_OPERATION_JP						"Operation"
#define TITLE_ADJUST_JP							"Adjust"
#define	TITLE_WIRELESS_JP						"Wireless"
#define	TITLE_FILAMENT_JP						"Filament"
#define TITLE_ABOUT_JP							"About"
#define TITLE_FAN_JP							"Fan"
#define TITLE_LANGUAGE_JP						"Language"
#define TITLE_PAUSE_JP							"Pause"
#define TITLE_CHANGESPEED_JP				    "Speed"
#define TITLE_CLOUD_TEXT_JP				        "Cloud"
#define TITLE_DIALOG_CONFIRM_JP				"Confirm"
#define TITLE_FILESYS_JP								"FileSys"

#define AUTO_SHUTDOWN_JP					"Auto"
#define MANUAL_SHUTDOWN_JP					"Manual"

#define DIALOG_CONFIRM_JP					"Confirm"
#define DIALOG_CANCLE_JP					"Cancel"
#define DIALOG_OK_JP						"OK"
#define DIALOG_RESET_JP						"Reset"
#define DIALOG_RETRY_JP						"Retry"
#define DIALOG_DISABLE_JP					"Disable"
#define DIALOG_PRINT_MODEL_JP				"Print this model?"
#define DIALOG_CANCEL_PRINT_JP				"Stop print?"
#define DIALOG_RETRY_JP						"Retry"
#define DIALOG_STOP_JP						"Stop"
#define DIALOG_REPRINT_FROM_BREAKPOINT_JP	                "Reprint from breakpoint?"
#define DIALOG_UNBIND_PRINTER_JP						    "Unbind the printer?"
#define DIALOG_ERROR_TIPS1_JP								"error:no file,please check it again."
#define DIALOG_ERROR_TIPS2_JP								"error:transaction failed.please check display baudrate \nwhether as the same as mainboard!"
#define DIALOG_ERROR_TIPS3_JP								"error:file name or path is too long!"
#define DIALOG_CLOSE_MACHINE_JP             "Closing machine......"
#define DIALOG_UNBIND_PRINTER_JP            "Unbind the printer?"
//***************德文****************************//
#define TOOL_TEXT_GN		        "Vorbereiten"
#define PREHEAT_TEXT_GN             "vorheizen"
#define	MOVE_TEXT_GN		        "Mobile"
#define HOME_TEXT_GN                "Null"
#define PRINT_TEXT_GN		        "drucken"
#define EXTRUDE_TEXT_GN             "Extrusion"
#define LEVELING_TEXT_GN            "Leveling"
#define AUTO_LEVELING_TEXT_GN       "Leveling"
#define SET_TEXT_GN			        "einrichten"
#define MORE_TEXT_GN                "mehr"

#define ADD_TEXT_GN			        "Zusatz"
#define DEC_TEXT_GN			        "Reduzierung"
#define EXTRUDER_1_TEXT_GN		    "Extrusion1"
#define EXTRUDER_2_TEXT_GN		    "Extrusion2"
#define HEATBED_TEXT_GN			    "Hot Bett"
#define TEXT_1C_GN					"1℃"
#define TEXT_5C_GN					"5℃"
#define TEXT_10C_GN					"10℃"
#define CLOSE_TEXT_GN				"schlie?en"

#define BACK_TEXT_GN					"Rückkehr"

#define AXIS_X_ADD_TEXT_GN				"X+"
#define AXIS_X_DEC_TEXT_GN				"X-"
#define AXIS_Y_ADD_TEXT_GN				"Y+"
#define AXIS_Y_DEC_TEXT_GN				"Y-"
#define AXIS_Z_ADD_TEXT_GN				"Z+"
#define AXIS_Z_DEC_TEXT_GN				"Z-"
#define TEXT_01MM_GN					"0.1mm"
#define TEXT_1MM_GN						"1mm"
#define TEXT_10MM_GN					"10mm"

#define HOME_X_TEXT_GN					"X"
#define HOME_Y_TEXT_GN					"Y"
#define HOME_Z_TEXT_GN					"Z"
#define HOME_ALL_TEXT_GN				"ALL"

#define PAGE_UP_TEXT_GN					"früher"
#define PAGE_DOWN_TEXT_GN				"n?chste\nSeite"

#define EXTRUDER_ADD_TEXT_GN		    "Futter"
#define EXTRUDER_DEC_TEXT_GN		    "Stripper"
#define EXTRUDE_1MM_TEXT_GN			    "1mm"
#define EXTRUDE_5MM_TEXT_GN			    "5mm"
#define EXTRUDE_10MM_TEXT_GN		    "10mm"
#define EXTRUDE_LOW_SPEED_TEXT_GN		"LOW"
#define EXTRUDE_MEDIUM_SPEED_TEXT_GN	"Mittlere"
#define EXTRUDE_HIGH_SPEED_TEXT_GN		"High"

#define LEVELING_POINT1_TEXT_GN				"Position1"
#define LEVELING_POINT2_TEXT_GN				"Position2"
#define LEVELING_POINT3_TEXT_GN				"Position3"
#define LEVELING_POINT4_TEXT_GN				"Position4"
#define LEVELING_POINT5_TEXT_GN				"Position5"

#define FILESYS_TEXT_GN						"FileSys"
#define WIFI_TEXT_GN						"WIFI"
#define FAN_TEXT_GN							"Fan"
#define ABOUT_TEXT_GN						"About"
#define BREAK_POINT_TEXT_GN					"Continu"
#define FILAMENT_TEXT_GN					"Filament"
#define LANGUAGE_TEXT_GN					"Language"
#define MOTO_OFF_TEXT_GN					"Moto-off"
#define SHUTDOWN_TEXT_GN					"Shutdown"

#define U_DISK_TEXT_GN						"U Disk"
#define SD_CARD_TEXT_GN						"SDCard"
#define WIFI_NAME_TEXT_GN					"WIFI:%s"
#define WIFI_KEY_TEXT_GN					"KEY:%s"
#define WIFI_IP_TEXT_GN						"IP:%s"
#define WIFI_AP_TEXT_GN						"STATE: AP"
#define WIFI_STA_TEXT_GN					"STATE: STA"
#define WIFI_CONNECTED_TEXT_GN				"CONNECTED"
#define WIFI_DISCONNECTED_TEXT_GN			"DISCONNECTED"
#define WIFI_EXCEPTION_TEXT_GN				"EXCEPTION"
#define CLOUD_TEXT_GN						"Cloud"
#define CLOUD_BIND_GN						"Bind"
#define CLOUD_UNBIND_GN						"Unbind"
#define CLOUD_UNBINDING_GN					"Unbinding"
#define CLOUD_DISCONNECTED_GN				"Disconnected"
#define CLOUD_UNBINDED_GN					"Unbinded"
#define CLOUD_BINDED_GN						"Binded"
#define CLOUD_DISABLE_GN					"Disable"

#define FAN_ADD_TEXT_GN						"ADD"
#define FAN_DEC_TEXT_GN						"DEC"
#define FAN_OPEN_TEXT_GN					"100%"
#define FAN_HALF_TEXT_GN					"50%"
#define FAN_CLOSE_TEXT_GN					"Close"
#define FAN_TIPS1_TEXT_GN					"FAN\n%d"
#define FAN_TIPS2_TEXT_GN					"FAN\nClose"

#define FILAMENT_IN_TEXT_GN					"In"
#define FILAMENT_OUT_TEXT_GN				"Out"
#define FILAMENT_EXT0_TEXT_GN				"E1"
#define FILAMENT_EXT1_TEXT_GN				"E2"
#define FILAMENT_HEAT_TEXT_GN				"Preheat"					
#define FILAMENT_STOP_TEXT_GN				"Stop"
#define FILAMENT_CHANGE_TEXT_GN				"Filament replace"
#define FILAMENT_TIPS2_TEXT_GN				"T:%d℃/%d℃"
#define FILAMENT_TIPS3_TEXT_GN				"loading..."
#define FILAMENT_TIPS4_TEXT_GN				"unloading..."
#define FILAMENT_TIPS5_TEXT_GN				"Temp is too low to go,please heat"
#define FILAMENT_TIPS6_TEXT_GN				"Completed"
#define FILAMENT_CHANGE_TEXT_GN				"Please click load \nor unload."
#define FILAMENT_DIALOG_LOAD_HEAT_TIPS_GN		"Heating up the nozzle,please wait..."
#define FILAMENT_DIALOG_UNLOAD_HEAT_TIPS_GN		"Heating up the nozzle,please wait..."
#define FILAMENT_DIALOG_LOAD_CONFIRM1_TIPS_GN           "Heat completed,please load filament \nto extruder,and click confirm \nfor start loading."
#define FILAMENT_DIALOG_LOAD_CONFIRM2_TIPS_GN           "Please load filament to extruder,\nand click confirm for start loading."
#define FILAMENT_DIALOG_UNLOAD_CONFIRM_TIPS_GN          "Heat completed,please \nclick confirm for start unloading.!"
#define FILAMENT_DIALOG_LOADING_TIPS_GN                 "Is loading ,please wait!"
#define FILAMENT_DIALOG_UNLOADING_TIPS_GN               "Is unloading,please wait!"
#define FILAMENT_DIALOG_LOAD_COMPLETE_TIPS_GN           "Load filament completed,\nclick confirm for return!"
#define FILAMENT_DIALOG_UNLOAD_COMPLETE_TIPS_GN         "Unload filament completed,\nclick confirm for return!"
#define FILAMENT_DIALOG_EMPTY_TIPS_GN                   "filament detection switch is no pressed!"

#define PRE_HEAT_EXT_TEXT_GN				"E%d\n%d℃/%d℃"
#define PRE_HEAT_BED_TEXT_GN				"Bed%d\n%d℃/%d℃"

#define FILE_LOADING_GN					"Loading......"
#define NO_FILE_AND_CHECK_GN					"No files found!\n   Check the file system configuration!"
#define NO_FILE_GN					"No files found!"

#define EXTRUDER_TEMP_TEXT_GN				"T:%d℃"
#define EXTRUDER_E_LENGTH1_TEXT_GN          "E%d:%dmm"
#define EXTRUDER_E_LENGTH2_TEXT_GN          "E%d:%dcm"
#define EXTRUDER_E_LENGTH3_TEXT_GN          "E%d:%dm"

#define ABOUT_TYPE_TEXT_GN					"TYPE: MKS TFT"
#define ABOUT_VERSION_TEXT_GN				"VERSION: 3.0.0"
#define ABOUT_WIFI_TEXT_GN					"WIFI:"

#define PRINTING_OPERATION_GN				"Operation"
#define PRINTING_PAUSE_GN					"Pause"
#define PRINTING_TEMP_GN					"Temp."
#define PRINTING_CHANGESPEED_GN				"Speed"
#define PRINTING_RESUME_GN					"Resume"
#define PRINTING_STOP_GN					"Stop"
#define PRINTING_MORE_GN					"More"
#define PRINTING_EXTRUDER_GN				"Extruder"
#define PRINTING_MOVE_GN                    "Move"

#define EXTRUDER_SPEED_GN					"Extrude"
#define MOVE_SPEED_GN						"Move"
#define EXTRUDER_SPEED_STATE_GN				"Extrude Speed"
#define MOVE_SPEED_STATE_GN					"Move Speed"
#define STEP_1PERCENT_GN					"1%"
#define STEP_5PERCENT_GN					"5%"
#define STEP_10PERCENT_GN					"10%"

#define TITLE_READYPRINT_GN						"ReadyPrint"
#define TITLE_PREHEAT_GN						"Preheat"
#define TITLE_MOVE_GN					        "Move"
#define TITLE_HOME_GN							"Home"
#define TITLE_EXTRUDE_GN						"Extrude"
#define TITLE_LEVELING_GN						"Leveling"
#define TITLE_SET_GN							"Set"
#define TITLE_MORE_GN							"More"
#define TITLE_CHOOSEFILE_GN						"ChooseFile"
#define TITLE_PRINTING_GN						"Printing"
#define TITLE_OPERATION_GN						"Operation"
#define TITLE_ADJUST_GN							"Adjust"
#define	TITLE_WIRELESS_GN						"Wireless"
#define	TITLE_FILAMENT_GN						"Filament"
#define TITLE_ABOUT_GN							"About"
#define TITLE_FAN_GN							"Fan"
#define TITLE_LANGUAGE_GN						"Language"
#define TITLE_PAUSE_GN							"Pause"
#define TITLE_CHANGESPEED_GN				    "Speed"
#define TITLE_CLOUD_TEXT_GN				        "Cloud"
#define TITLE_DIALOG_CONFIRM_GN				"Confirm"
#define TITLE_FILESYS_GN								"FileSys"

#define AUTO_SHUTDOWN_GN					"Auto"
#define MANUAL_SHUTDOWN_GN					"Manual"

#define DIALOG_CONFIRM_GN					"Confirm"
#define DIALOG_CANCLE_GN					"Cancel"
#define DIALOG_OK_GN						"OK"
#define DIALOG_RESET_GN						"Reset"
#define DIALOG_RETRY_GN						"Retry"
#define DIALOG_DISABLE_GN					"Disable"
#define DIALOG_PRINT_MODEL_GN				"Print this model?"
#define DIALOG_CANCEL_PRINT_GN				"Stop print?"
#define DIALOG_RETRY_GN									"Retry"
#define DIALOG_STOP_GN									"Stop"
#define DIALOG_REPRINT_FROM_BREAKPOINT_GN	            "Reprint from breakpoint?"
#define DIALOG_UNBIND_PRINTER_GN						"Unbind the printer?"
#define DIALOG_ERROR_TIPS1_GN								"error:no file,please check it again."
#define DIALOG_ERROR_TIPS2_GN								"error:transaction failed.please check display baudrate \nwhether as the same as mainboard!"
#define DIALOG_ERROR_TIPS3_GN								"error:file name or path is too long!"
#define DIALOG_CLOSE_MACHINE_GN             "Closing machine......"
#define DIALOG_UNBIND_PRINTER_GN            "Unbind the printer?"
#define DIALOG_WIFI_ENABLE_GN            "Enable"
#define DIALOG_WIFI_DISABLE_GN           "Disable"
#define DIALOG_TEXT_WIFI_ENABLE_GN       "Enable"
#define DIALOG_TEXT_WIFI_DISABLE_GN      "Disable"

#define DIALOG_TEXT_NO_TEMP_TIPS_GN     "Keine Zieltemperatur, \nbitte w?hlen Sie die Standardtemperatur \noder stellen Sie die Temperatur ein"
#define DIALOG_TEXT_DEFAULT_TEMP_GN     "Standard"
#define DIALOG_TEXT_SETTING_TEMP_GN     "Einstellung"
//*************法文****************************//
#define TOOL_TEXT_FR		        "prêt"
#define PREHEAT_TEXT_FR             "Préchauffe"
#define	MOVE_TEXT_FR		        "Déplace"
#define HOME_TEXT_FR                "Acceuil"
#define PRINT_TEXT_FR		        "Impression"
#define EXTRUDE_TEXT_FR             "Extruder"
#define LEVELING_TEXT_FR            "Leveling"
#define AUTO_LEVELING_TEXT_FR       "AutoLevel"
#define SET_TEXT_FR			        "Config"
#define MORE_TEXT_FR                "Plus"

#define ADD_TEXT_FR			        "Ajouter"
#define DEC_TEXT_FR			        "Réduire"
#define EXTRUDER_1_TEXT_FR		    "Extr1"
#define EXTRUDER_2_TEXT_FR		    "Extr2"
#define HEATBED_TEXT_FR			    "Hotlit"
#define TEXT_1C_FR					"1℃"
#define TEXT_5C_FR					"5℃"
#define TEXT_10C_FR					"10℃"
#define CLOSE_TEXT_FR				"Off"

#define BACK_TEXT_FR					"Arrière"

#define AXIS_X_ADD_TEXT_FR				"X+"
#define AXIS_X_DEC_TEXT_FR				"X-"
#define AXIS_Y_ADD_TEXT_FR				"Y+"
#define AXIS_Y_DEC_TEXT_FR				"Y-"
#define AXIS_Z_ADD_TEXT_FR				"Z+"
#define AXIS_Z_DEC_TEXT_FR				"Z-"
#define TEXT_01MM_FR					"0.1mm"
#define TEXT_1MM_FR						"1mm"
#define TEXT_10MM_FR					"10mm"

#define HOME_X_TEXT_FR					"X"
#define HOME_Y_TEXT_FR					"Y"
#define HOME_Z_TEXT_FR					"Z"
#define HOME_ALL_TEXT_FR				"ALL"

#define PAGE_UP_TEXT_FR					"En haut"
#define PAGE_DOWN_TEXT_FR				"En bas"

#define EXTRUDER_IN_TEXT_FR		    "Insérer"
#define EXTRUDER_OUT_TEXT_FR		    "éjecter"
#define EXTRUDE_1MM_TEXT_FR			    "1mm"
#define EXTRUDE_5MM_TEXT_FR			    "5mm"
#define EXTRUDE_10MM_TEXT_FR		    "10mm"
#define EXTRUDE_LOW_SPEED_TEXT_FR		"Lente"
#define EXTRUDE_MEDIUM_SPEED_TEXT_FR	"Moyen"
#define EXTRUDE_HIGH_SPEED_TEXT_FR		"Rapide"

#define LEVELING_POINT1_TEXT_FR			"Premier"
#define LEVELING_POINT2_TEXT_FR			"Seconde"
#define LEVELING_POINT3_TEXT_FR			"Troisième"
#define LEVELING_POINT4_TEXT_FR			"Quatrième"
#define LEVELING_POINT5_TEXT_FR			"Cinquième"

#define FILESYS_TEXT_FR					"Fichier"
#define WIFI_TEXT_FR					"WiFi"
#define FAN_TEXT_FR						"Fan"
#define ABOUT_TEXT_FR					"A propos"
#define BREAK_POINT_TEXT_FR				"Continuer"
#define FILAMENT_TEXT_FR				"Remplacer"
#define LANGUAGE_TEXT_FR				"Langue"
#define MOTOR_OFF_TEXT_FR				"M-hors"
#define SHUTDOWN_TEXT_FR				"Eteindre"

#define U_DISK_TEXT_FR					"Clé usb"
#define SD_CARD_TEXT_FR					"Carte SD"
#define WIFI_NAME_TEXT_FR				"WiFi:"
#define WIFI_KEY_TEXT_FR				"Key:"
#define WIFI_IP_TEXT_FR					"IP:"
#define WIFI_AP_TEXT_FR					"Etat: AP"
#define WIFI_STA_TEXT_FR				"Etat: STA"
#define WIFI_CONNECTED_TEXT_FR			"Connecté"
#define WIFI_DISCONNECTED_TEXT_FR		"Déconnecté"
#define WIFI_EXCEPTION_TEXT_FR			"Exception"
#define CLOUD_TEXT_FR					"Cloud"
#define CLOUD_BIND_FR					"Lié"
#define CLOUD_UNBIND_FR					"Délier"
#define CLOUD_UNBINDING_FR				"Délier"
#define CLOUD_DISCONNECTED_FR			"Déconnecté"
#define CLOUD_UNBINDED_FR				"Délier"
#define CLOUD_BINDED_FR					"Lié"
#define CLOUD_DISABLE_FR				"Désactiver"

#define FAN_ADD_TEXT_FR					"Ajouter"
#define FAN_DEC_TEXT_FR					"Réduire"
#define FAN_OPEN_TEXT_FR				"100%"
#define FAN_HALF_TEXT_FR				"50%"
#define FAN_CLOSE_TEXT_FR				"0%"
#define FAN_TIPS1_TEXT_FR				"Fan"
#define FAN_TIPS2_TEXT_FR				"Fan\n0"

#define FILAMENT_IN_TEXT_FR						"Insérer"
#define FILAMENT_OUT_TEXT_FR					"éjecter"
#define FILAMENT_EXT0_TEXT_FR					"Extr1"
#define FILAMENT_EXT1_TEXT_FR					"Extr2"
#define FILAMENT_HEAT_TEXT_FR					"Preheat"					
#define FILAMENT_STOP_TEXT_FR					"Arrêter"
#define FILAMENT_CHANGE_TEXT_FR				"Filament remplacer"
#define FILAMENT_TIPS2_TEXT_FR				"T:"
#define FILAMENT_TIPS3_TEXT_FR				"Insérer le filament..."
#define FILAMENT_TIPS4_TEXT_FR				"éjecter le filament..."
#define FILAMENT_TIPS5_TEXT_FR				"Température trop basse pour démarrer, chauffez svp"
#define FILAMENT_TIPS6_TEXT_FR				"Terminé"
#define FILAMENT_CHANGE_TEXT_FR				"Please click load \nor unload."
#define FILAMENT_DIALOG_LOAD_HEAT_TIPS_FR		"Heating up the nozzle,please wait..."
#define FILAMENT_DIALOG_UNLOAD_HEAT_TIPS_FR		"Heating up the nozzle,please wait..."
#define FILAMENT_DIALOG_LOAD_CONFIRM1_TIPS_FR           "Heat completed,please load filament \nto extruder,and click confirm \nfor start loading."
#define FILAMENT_DIALOG_LOAD_CONFIRM2_TIPS_FR           "Please load filament to extruder,\nand click confirm for start loading."
#define FILAMENT_DIALOG_UNLOAD_CONFIRM_TIPS_FR          "Heat completed,please \nclick confirm for start unloading.!"
#define FILAMENT_DIALOG_LOADING_TIPS_FR                 "Is loading ,please wait!"
#define FILAMENT_DIALOG_UNLOADING_TIPS_FR               "Is unloading,please wait!"
#define FILAMENT_DIALOG_LOAD_COMPLETE_TIPS_FR           "Load filament completed,\nclick confirm for return!"
#define FILAMENT_DIALOG_UNLOAD_COMPLETE_TIPS_FR         "Unload filament completed,\nclick confirm for return!"
#define FILAMENT_DIALOG_EMPTY_TIPS_FR                   "filament detection switch is no pressed!"

#define PRE_HEAT_EXT_TEXT_FR						"E"
#define PRE_HEAT_BED_TEXT_FR						"Bed"

#define FILE_LOADING_FR				"Chargement......"
#define NO_FILE_AND_CHECK_FR					"Aucun fichier,\nvérifiez à nouveau!"
#define NO_FILE_FR					"Pas de fichier!"



#define EXTRUDER_TEMP_TEXT_FR				"T:"
#define EXTRUDER_E_LENGTH1_TEXT_FR          "E"
#define EXTRUDER_E_LENGTH2_TEXT_FR          "E"
#define EXTRUDER_E_LENGTH3_TEXT_FR          "E"

#define ABOUT_TYPE_TEXT_FR					"TYPE: MKS TFT"
#define ABOUT_VERSION_TEXT_FR				"VERSION: 3.0.0"
#define ABOUT_WIFI_TEXT_FR					"WIFI:"

#define PRINTING_OPERATION_FR				"Option"
#define PRINTING_PAUSE_FR					"Pause"
#define PRINTING_TEMP_FR					"Temp."
#define PRINTING_CHANGESPEED_FR				"Speed"
#define PRINTING_RESUME_FR					"Reprendre"
#define PRINTING_STOP_FR					"Stop"
#define PRINTING_MORE_FR					"Plus"
#define PRINTING_EXTRUDER_FR				"Extruder"
#define PRINTING_MOVE_FR                    "Déplace"

#define EXTRUDER_SPEED_FR					"Extruder"
#define MOVE_SPEED_FR						"Déplace"
#define EXTRUDER_SPEED_STATE_FR				"Vitesse d'extrusion"
#define MOVE_SPEED_STATE_FR					"vitesse de déplacement"
#define STEP_1PERCENT_FR					"1%"
#define STEP_5PERCENT_FR					"5%"
#define STEP_10PERCENT_FR					"10%"

#define TITLE_READYPRINT_FR						"Prête"
#define TITLE_PREHEAT_FR						"Préchauffe"
#define TITLE_MOVE_FR					        "Déplace"
#define TITLE_HOME_FR							"Acceuil"
#define TITLE_EXTRUDE_FR						"Extruder"
#define TITLE_LEVELING_FR						"Leveling"
#define TITLE_SET_FR							"Paramètres"
#define TITLE_MORE_FR							"Plus"
#define TITLE_CHOOSEFILE_FR						"Fichier"
#define TITLE_PRINTING_FR						"Pimpression"
#define TITLE_OPERATION_FR						"Option"
#define TITLE_ADJUST_FR							"Réglage"
#define	TITLE_WIRELESS_FR						"Sans fil"
#define	TITLE_FILAMENT_FR						"Remplacer"
#define TITLE_ABOUT_FR							"A propos"
#define TITLE_FAN_FR							"Ventilateur"
#define TITLE_LANGUAGE_FR						"Langue"
#define TITLE_PAUSE_FR							"Pause"
#define TITLE_CHANGESPEED_FR				    "Speed"
#define TITLE_CLOUD_TEXT_FR				        "Cloud"
#define TITLE_DIALOG_CONFIRM_FR				"Confirm"
#define TITLE_FILESYS_FR								"FileSys"

#define DIALOG_CLOSE_MACHINE_FR             "Closing machine......"

#define AUTO_SHUTDOWN_FR							"Auto"
#define MANUAL_SHUTDOWN_FR							"Manuel"

#define DIALOG_CONFIRM_FR							"Confirmer"
#define DIALOG_CANCLE_FR							"Annuler"
#define DIALOG_OK_FR								"OK"
#define DIALOG_RESET_FR								"Réinitialiser"
#define DIALOG_RETRY_FR								"Recommencez"
#define DIALOG_DISABLE_FR							"Disable"
#define DIALOG_PRINT_MODEL_FR				        "Imprimer le fichier?"
#define DIALOG_CANCEL_PRINT_FR				        "Arrêter?"

#define DIALOG_STOP_FR									"Arrêter"
#define DIALOG_REPRINT_FROM_BREAKPOINT_FR	            "Continuer?"
#define DIALOG_UNBIND_PRINTER_FR						"Non lié?"
#define DIALOG_ERROR_TIPS1_FR			"Erreur:error:Aucun fichier, \nvérifiez à nouveau."
#define DIALOG_ERROR_TIPS2_FR			"Erreur:La opération a échoué. \nVerifiez que le baudrate de l'écran et de \nla carte mère soient identique!"
#define DIALOG_ERROR_TIPS3_FR		        "Erreur: le nom du fichier ou le \nchemin d'accès est trop long."
#define DIALOG_UNBIND_PRINTER_FR                "Unbind the printer?"
#define DIALOG_WIFI_ENABLE_FR            "Activer"
#define DIALOG_WIFI_DISABLE_FR           "Désactiver"
#define DIALOG_TEXT_WIFI_ENABLE_FR       "Activation"
#define DIALOG_TEXT_WIFI_DISABLE_FR      "Désactivé"

#define DIALOG_TEXT_NO_TEMP_TIPS_FR     "Pas de température cible, \ns'il vous pla?t choisir la température par dé\nfaut ou régler la température"
#define DIALOG_TEXT_DEFAULT_TEMP_FR     "Par défaut"
#define DIALOG_TEXT_SETTING_TEMP_FR     "Réglage"
//****************俄语***************************//
#define TOOL_TEXT_RU		    "инструмент"
#define PREHEAT_TEXT_RU         " нагрев"
#define	MOVE_TEXT_RU		    "движение"
#define HOME_TEXT_RU            "домой"
#define PRINT_TEXT_RU		    " печать"
#define EXTRUDE_TEXT_RU         "экструзия"
#define LEVELING_TEXT_RU        "уровень"
#define AUTO_LEVELING_TEXT_RU   "aвто"
#define SET_TEXT_RU			    "настройки"
#define MORE_TEXT_RU            "больше"

#define ADD_TEXT_RU			    "добавить"
#define DEC_TEXT_RU			    "уменьшить"
#define EXTRUDER_1_TEXT_RU		"экструдер1"
#define EXTRUDER_2_TEXT_RU		"экструдер2"
#define HEATBED_TEXT_RU			"стол"
#define TEXT_1C_RU				"1℃"
#define TEXT_5C_RU				"5℃"
#define TEXT_10C_RU				"10℃"
#define CLOSE_TEXT_RU			"выкл"

#define BACK_TEXT_RU					"назад"

#define AXIS_X_ADD_TEXT_RU				"X+"
#define AXIS_X_DEC_TEXT_RU				"X-"
#define AXIS_Y_ADD_TEXT_RU				"Y+"
#define AXIS_Y_DEC_TEXT_RU				"Y-"
#define AXIS_Z_ADD_TEXT_RU				"Z+"
#define AXIS_Z_DEC_TEXT_RU				"Z-"
#define TEXT_01MM_RU					"0.1mm"
#define TEXT_1MM_RU						"1mm"
#define TEXT_10MM_RU					"10mm"

#define HOME_X_TEXT_RU					"X"
#define HOME_Y_TEXT_RU					"Y"
#define HOME_Z_TEXT_RU					"Z"
#define HOME_ALL_TEXT_RU				"Home"

#define PAGE_UP_TEXT_RU					"вверх"
#define PAGE_DOWN_TEXT_RU				"вниз"

#define EXTRUDER_IN_TEXT_RU		        "втянуть"
#define EXTRUDER_OUT_TEXT_RU		    "выдавить"
#define EXTRUDE_1MM_TEXT_RU			    "1mm"
#define EXTRUDE_5MM_TEXT_RU			    "5mm"
#define EXTRUDE_10MM_TEXT_RU		    "10mm"
#define EXTRUDE_LOW_SPEED_TEXT_RU		"мин"
#define EXTRUDE_MEDIUM_SPEED_TEXT_RU	"сред"
#define EXTRUDE_HIGH_SPEED_TEXT_RU		"выс"

#define LEVELING_POINT1_TEXT_RU				"1точка"
#define LEVELING_POINT2_TEXT_RU				"2точка"
#define LEVELING_POINT3_TEXT_RU				"3точка"
#define LEVELING_POINT4_TEXT_RU				"4точка"
#define LEVELING_POINT5_TEXT_RU				"5точка"

#define FILESYS_TEXT_RU						"система"
#define WIFI_TEXT_RU						"WiFi"
#define FAN_TEXT_RU							"вентилятор"
#define ABOUT_TEXT_RU						"инфо"
#define BREAK_POINT_TEXT_RU					"продолжить"
#define FILAMENT_TEXT_RU					"замена"
#define LANGUAGE_TEXT_RU					"язык"
#define MOTOR_OFF_TEXT_RU					"отклмотор"
#define SHUTDOWN_TEXT_RU					"выключение"

#define U_DISK_TEXT_RU						"U диск"
#define SD_CARD_TEXT_RU						"SD диск"
#define WIFI_NAME_TEXT_RU					"WiFi:"
#define WIFI_KEY_TEXT_RU					"пароль:"
#define WIFI_IP_TEXT_RU						"IP:%s"
#define WIFI_AP_TEXT_RU						"режим: AP"
#define WIFI_STA_TEXT_RU					"режим: STA"
#define WIFI_CONNECTED_TEXT_RU				"подключен"
#define WIFI_DISCONNECTED_TEXT_RU			"не подключен"
#define WIFI_EXCEPTION_TEXT_RU				"исключение"
#define CLOUD_TEXT_RU						"облако"
#define CLOUD_BIND_RU						"соединён"
#define CLOUD_UNBIND_RU						"не соединён"
#define CLOUD_UNBINDING_RU					"Unbinding"
#define CLOUD_DISCONNECTED_RU				"Disconnected"
#define CLOUD_UNBINDED_RU					"Unbinded"
#define CLOUD_BINDED_RU						"Binded"
#define CLOUD_DISABLE_RU					"Disable"

#define FAN_ADD_TEXT_RU						"добавить"
#define FAN_DEC_TEXT_RU						"уменьшить"
#define FAN_OPEN_TEXT_RU					"100%"
#define FAN_HALF_TEXT_RU					"50%"
#define FAN_CLOSE_TEXT_RU					"откл"
#define FAN_TIPS1_TEXT_RU					"вентилятор"
#define FAN_TIPS2_TEXT_RU					"вентилятор\nоткл"

#define FILAMENT_IN_TEXT_RU					"втянуть"
#define FILAMENT_OUT_TEXT_RU				"выдавить"
#define FILAMENT_EXT0_TEXT_RU				"E1"
#define FILAMENT_EXT1_TEXT_RU				"E2"
#define FILAMENT_HEAT_TEXT_RU				"нагрев"					
#define FILAMENT_STOP_TEXT_RU				"стоп"
#define FILAMENT_CHANGE_TEXT_RU				"замена"
#define FILAMENT_TIPS2_TEXT_RU				"T:"
#define FILAMENT_TIPS3_TEXT_RU				"втянуть..."
#define FILAMENT_TIPS4_TEXT_RU				"вядавить..."
#define FILAMENT_TIPS5_TEXT_RU				"Низкая температура, \nнеобходим нагрев"
#define FILAMENT_TIPS6_TEXT_RU				"завершено"
#define FILAMENT_CHANGE_TEXT_RU				"Please click load \nor unload."
#define FILAMENT_DIALOG_LOAD_HEAT_TIPS_RU		"Heating up the nozzle,please wait..."
#define FILAMENT_DIALOG_UNLOAD_HEAT_TIPS_RU		"Heating up the nozzle,please wait..."
#define FILAMENT_DIALOG_LOAD_CONFIRM1_TIPS_RU           "Heat completed,please load filament \nto extruder,and click confirm \nfor start loading."
#define FILAMENT_DIALOG_LOAD_CONFIRM2_TIPS_RU           "Please load filament to extruder,\nand click confirm for start loading."
#define FILAMENT_DIALOG_UNLOAD_CONFIRM_TIPS_RU          "Heat completed,please \nclick confirm for start unloading.!"
#define FILAMENT_DIALOG_LOADING_TIPS_RU                 "Is loading ,please wait!"
#define FILAMENT_DIALOG_UNLOADING_TIPS_RU               "Is unloading,please wait!"
#define FILAMENT_DIALOG_LOAD_COMPLETE_TIPS_RU           "Load filament completed,\nclick confirm for return!"
#define FILAMENT_DIALOG_UNLOAD_COMPLETE_TIPS_RU         "Unload filament completed,\nclick confirm for return!"
#define FILAMENT_DIALOG_EMPTY_TIPS_RU                   "filament detection switch is no pressed!"

#define PRE_HEAT_EXT_TEXT_RU				"E"
#define PRE_HEAT_BED_TEXT_RU				"стол"

#define FILE_LOADING_RU					"загрузка......"
#define NO_FILE_AND_CHECK_RU					"нет файла, \n   попробуйте ещё раз !"
#define NO_FILE_RU					"нет файла!"

#define EXTRUDER_TEMP_TEXT_RU				"T:"
#define EXTRUDER_E_LENGTH1_TEXT_RU          "E"
#define EXTRUDER_E_LENGTH2_TEXT_RU          "E"
#define EXTRUDER_E_LENGTH3_TEXT_RU          "E"

#define ABOUT_TYPE_TEXT_RU					"Type: MKS TFT"
#define ABOUT_VERSION_TEXT_RU				"Version: 3.0.0"
#define ABOUT_WIFI_TEXT_RU					"WiFi:"

#define PRINTING_OPERATION_RU				"управление"
#define PRINTING_PAUSE_RU					"пауза"
#define PRINTING_TEMP_RU					"темп"
#define PRINTING_CHANGESPEED_RU				"скорости"
#define PRINTING_RESUME_RU					"возобновить"
#define PRINTING_STOP_RU					"стоп"
#define PRINTING_MORE_RU					"больше"
#define PRINTING_EXTRUDER_RU			    "экстр"
#define PRINTING_MOVE_RU                    "движение"

#define EXTRUDER_SPEED_RU					"экстр"
#define MOVE_SPEED_RU						"движ"
#define EXTRUDER_SPEED_STATE_RU				"скорость экстр"
#define MOVE_SPEED_STATE_RU					"скорость движ"
#define STEP_1PERCENT_RU					"1%"
#define STEP_5PERCENT_RU					"5%"
#define STEP_10PERCENT_RU					"10%"

#define TITLE_READYPRINT_RU						"готов к"
#define TITLE_PREHEAT_RU						"движение"
#define TITLE_MOVE_RU					        "движение"
#define TITLE_HOME_RU							"Home"
#define TITLE_EXTRUDE_RU						"экструзия"
#define TITLE_LEVELING_RU						"уровень"
#define TITLE_SET_RU							"настройки"
#define TITLE_MORE_RU							"больше"
#define TITLE_CHOOSEFILE_RU						"файла"
#define TITLE_PRINTING_RU						"печать"
#define TITLE_OPERATION_RU						"управление"
#define TITLE_ADJUST_RU							"регулировать"
#define	TITLE_WIRELESS_RU						"Wireless"
#define	TITLE_FILAMENT_RU						"замена"
#define TITLE_ABOUT_RU							"инфо"
#define TITLE_FAN_RU							"вентилятор"
#define TITLE_LANGUAGE_RU						"язык"
#define TITLE_PAUSE_RU							"пауза"
#define TITLE_CHANGESPEED_RU				    "скорости"
#define TILE_TOOL_RU						    "инструмент"
#define TITLE_CLOUD_TEXT_RU				        "Cloud"
#define TITLE_DIALOG_CONFIRM_RU				"Confirm"
#define TITLE_FILESYS_RU								"FileSys"

#define AUTO_SHUTDOWN_RU					"авто-откл"
#define MANUAL_SHUTDOWN_RU					"ручн-откл"

#define DIALOG_CONFIRM_RU					"да"//"подтвердить"
#define DIALOG_CANCLE_RU					"отмена"
#define DIALOG_OK_RU						"да"
#define DIALOG_RESET_RU						"сброс"
#define DIALOG_RETRY_RU						"повтор"
#define DIALOG_DISABLE_RU					"запретить"
#define DIALOG_PRINT_MODEL_RU				"печать модели?"
#define DIALOG_CANCEL_PRINT_RU				"стоп?"
#define DIALOG_STOP_RU						"стоп"
#define DIALOG_REPRINT_FROM_BREAKPOINT_RU	"продолжить?"
#define DIALOG_UNBIND_PRINTER_RU			"разрыв?"
#define DIALOG_ERROR_TIPS1_RU				"ошибка:нет файла, попробуйте ещё раз."
#define DIALOG_ERROR_TIPS2_RU				"ошибка:сбой передачи. установите скорость \nпередачи данных как на плате управления!"
#define DIALOG_ERROR_TIPS3_RU				"ошибка: имя файла слишком длинное!"
#define DIALOG_CLOSE_MACHINE_RU             "Closing machine......"
#define DIALOG_UNBIND_PRINTER_RU            "Unbind the printer?"
#define DIALOG_WIFI_ENABLE_RU            "Включить"
#define DIALOG_WIFI_DISABLE_RU           "Отключение"
#define DIALOG_TEXT_WIFI_ENABLE_RU       "Включить"
#define DIALOG_TEXT_WIFI_DISABLE_RU      "запрещать"

#define DIALOG_TEXT_NO_TEMP_TIPS_RU     "Нет заданной температуры, пожалуйста, \nвыберите температуру по умолчанию \nили установите температуру"
#define DIALOG_TEXT_DEFAULT_TEMP_RU     "дефолт"
#define DIALOG_TEXT_SETTING_TEMP_RU     "Настройка"
//****************西班牙语***************************
#define TOOL_TEXT_SP		    "Ajustes"
#define PREHEAT_TEXT_SP         "Preheat"//"precalent\nar"
#define	MOVE_TEXT_SP		    "Mover"
#define HOME_TEXT_SP            "Origen"
#define PRINT_TEXT_SP		    "Impresión"
#define EXTRUDE_TEXT_SP         "Extrusión"
#define LEVELING_TEXT_SP        "Leveling"//"nivelac\nión"
#define AUTO_LEVELING_TEXT_SP   "Autolevel"//"auto\nnivelación"
#define SET_TEXT_SP			    "Config"
#define MORE_TEXT_SP            "Más"

#define ADD_TEXT_SP			    "Más"
#define DEC_TEXT_SP			    "Menos"
#define EXTRUDER_1_TEXT_SP		"Extrusor1"
#define EXTRUDER_2_TEXT_SP		"Extrusor2"
#define HEATBED_TEXT_SP			"Cama"
#define TEXT_1C_SP				"1℃"
#define TEXT_5C_SP				"5℃"
#define TEXT_10C_SP				"10℃"
#define CLOSE_TEXT_SP			"Apagar"

#define BACK_TEXT_SP			"Atrás"

#define AXIS_X_ADD_TEXT_SP		"X+"
#define AXIS_X_DEC_TEXT_SP		"X-"
#define AXIS_Y_ADD_TEXT_SP	    "Y+"
#define AXIS_Y_DEC_TEXT_SP		"Y-"
#define AXIS_Z_ADD_TEXT_SP		"Z+"
#define AXIS_Z_DEC_TEXT_SP		"Z-"
#define TEXT_01MM_SP			"0.1mm"
#define TEXT_1MM_SP				"1mm"
#define TEXT_10MM_SP			"10mm"

#define HOME_X_TEXT_SP			"EJE X"
#define HOME_Y_TEXT_SP			"EJE Y"
#define HOME_Z_TEXT_SP			"EJE Z"
#define HOME_ALL_TEXT_SP		"Todos"

#define PAGE_UP_TEXT_SP					"Arriba"
#define PAGE_DOWN_TEXT_SP				"Abajo"

#define EXTRUDER_IN_TEXT_SP		    "Dentro"
#define EXTRUDER_OUT_TEXT_SP		    "Fuera"
#define EXTRUDE_1MM_TEXT_SP			    "1mm"
#define EXTRUDE_5MM_TEXT_SP			    "5mm"
#define EXTRUDE_10MM_TEXT_SP		    "10mm"
#define EXTRUDE_LOW_SPEED_TEXT_SP		"Baja"
#define EXTRUDE_MEDIUM_SPEED_TEXT_SP	"Media"
#define EXTRUDE_HIGH_SPEED_TEXT_SP		"Alta"

#define LEVELING_POINT1_TEXT_SP			"Primero"
#define LEVELING_POINT2_TEXT_SP			"Segundo"
#define LEVELING_POINT3_TEXT_SP			"Tercero"
#define LEVELING_POINT4_TEXT_SP			"Cuarto"
#define LEVELING_POINT5_TEXT_SP			"Quinto"

#define FILESYS_TEXT_SP					"Puerto"
#define WIFI_TEXT_SP					"WiFi"
#define FAN_TEXT_SP						"Vent."
#define ABOUT_TEXT_SP					"Acerca"
#define BREAK_POINT_TEXT_SP				"Continuar"
#define FILAMENT_TEXT_SP				"Cambiar"
#define LANGUAGE_TEXT_SP				"Language"
#define MOTOR_OFF_TEXT_SP				"Apagar motor"
#define SHUTDOWN_TEXT_SP				"Apagar"

#define U_DISK_TEXT_SP					"Pendrive"
#define SD_CARD_TEXT_SP					"SD"
#define WIFI_NAME_TEXT_SP				"WiFi:"
#define WIFI_KEY_TEXT_SP				"Contraseña:"
#define WIFI_IP_TEXT_SP					"IP:"
#define WIFI_AP_TEXT_SP					"Estado: AP"
#define WIFI_STA_TEXT_SP				"Estado: STA"
#define WIFI_CONNECTED_TEXT_SP				"Conectado"
#define WIFI_DISCONNECTED_TEXT_SP			"Desconectado"
#define WIFI_EXCEPTION_TEXT_SP				"Excepción"
#define CLOUD_TEXT_SP						"Nube"
#define CLOUD_BIND_SP						"Atado"
#define CLOUD_UNBIND_SP					    "Sin atar"
#define CLOUD_UNBINDING_SP					"Unbinding"
#define CLOUD_DISCONNECTED_SP				"Disconnected"
#define CLOUD_UNBINDED_SP					"Unbinded"
#define CLOUD_BINDED_SP						"Binded"
#define CLOUD_DISABLE_SP					"Disable"

#define FAN_ADD_TEXT_SP						"Añadir"
#define FAN_DEC_TEXT_SP						"Reducir"
#define FAN_OPEN_TEXT_SP					"100%"
#define FAN_HALF_TEXT_SP					"50%"
#define FAN_CLOSE_TEXT_SP					"0%"
#define FAN_TIPS1_TEXT_SP					"Ventilador"
#define FAN_TIPS2_TEXT_SP					"Ventilador\n0"

#define FILAMENT_IN_TEXT_SP					"Dentro"
#define FILAMENT_OUT_TEXT_SP				"Fuera"
#define FILAMENT_EXT0_TEXT_SP				"E1"
#define FILAMENT_EXT1_TEXT_SP				"E2"
#define FILAMENT_HEAT_TEXT_SP				"Precalentar"					
#define FILAMENT_STOP_TEXT_SP				"Parar"
#define FILAMENT_CHANGE_TEXT_SP				"Filamento"
#define FILAMENT_TIPS2_TEXT_SP				"T:"
#define FILAMENT_TIPS3_TEXT_SP				"Dentro..."
#define FILAMENT_TIPS4_TEXT_SP				"Fuera..."
#define FILAMENT_TIPS5_TEXT_SP				"Temperatura demasiado baja, por favor calentar"
#define FILAMENT_TIPS6_TEXT_SP				"Completado"

#define FILAMENT_CHANGE_TEXT_SP				"Please click load \nor unload."
/*
#define FILAMENT_DIALOG_LOAD_HEAT_TIPS_SP		"Heating up the nozzle,please wait..."
#define FILAMENT_DIALOG_UNLOAD_HEAT_TIPS_SP		"Heating up the nozzle,please wait..."
#define FILAMENT_DIALOG_LOAD_CONFIRM1_TIPS_SP           "Heat completed,please load filament \nto extruder,and click confirm \nfor start loading."
#define FILAMENT_DIALOG_LOAD_CONFIRM2_TIPS_SP           "Please load filament to extruder,\nand click confirm for start loading."
#define FILAMENT_DIALOG_UNLOAD_CONFIRM_TIPS_SP          "Heat completed,please \nclick confirm for start unloading.!"
#define FILAMENT_DIALOG_LOADING_TIPS_SP                 "Is loading ,please wait!"
#define FILAMENT_DIALOG_UNLOADING_TIPS_SP               "Is unloading,please wait!"
#define FILAMENT_DIALOG_LOAD_COMPLETE_TIPS_SP           "Load filament completed,\nclick confirm for return!"
#define FILAMENT_DIALOG_UNLOAD_COMPLETE_TIPS_SP         "Unload filament completed,\nclick confirm for return!"
*/
  #define FILAMENT_DIALOG_LOAD_HEAT_TIPS_SP		"Calentando el extrusor,\npor favor espere..."
  #define FILAMENT_DIALOG_UNLOAD_HEAT_TIPS_SP		"Calentando el extrusor,\npor favor espere..."
  #define FILAMENT_DIALOG_LOAD_CONFIRM1_TIPS_SP           "Temperatura alcanzada.Inserte el\nfilamento y luego presione\"Confirmar\"\npara comenzar la carga."
  #define FILAMENT_DIALOG_LOAD_CONFIRM2_TIPS_SP           "Inserte el filamento y\nluego presione\"Confirmar\"para\ncomenzar la carga."
  #define FILAMENT_DIALOG_UNLOAD_CONFIRM_TIPS_SP          "Temperatura alcanzada.\nPresione\"Confirmar\"para retirar\nel filamento."
  #define FILAMENT_DIALOG_LOADING_TIPS_SP                 "Cargando filamento,\npor favor espere."
  #define FILAMENT_DIALOG_UNLOADING_TIPS_SP               "Retirando filamento,\npor favor espere."
  #define FILAMENT_DIALOG_LOAD_COMPLETE_TIPS_SP           "Filamento cargado,\npresione\"Confirmar\"."
  #define FILAMENT_DIALOG_UNLOAD_COMPLETE_TIPS_SP         "Filamento retirado,\npresione\"Confirmar\"."
	#define FILAMENT_DIALOG_EMPTY_TIPS_SP                   "el interruptor de detección \nde filamento no está presionado!"
	
#define PRE_HEAT_EXT_TEXT_SP				"Extrusor"
#define PRE_HEAT_BED_TEXT_SP				"Cama"

#define FILE_LOADING_SP					"Cargando......"
#define NO_FILE_AND_CHECK_SP					"Archivo no encontrado, \n   por favor insertar SD o disco USB!"
#define NO_FILE_SP					"Sin archivo!"



#define EXTRUDER_TEMP_TEXT_SP				"T:"
#define EXTRUDER_E_LENGTH1_TEXT_SP          "Extrusor"
#define EXTRUDER_E_LENGTH2_TEXT_SP          "Extrusor"
#define EXTRUDER_E_LENGTH3_TEXT_SP          "Extrusor"

#define ABOUT_TYPE_TEXT_SP					"Pantalla: MKS TFT"
#define ABOUT_VERSION_TEXT_SP				"Firmware: 3.0.1"
#define ABOUT_WIFI_TEXT_SP					"WIFI:"

#define PRINTING_OPERATION_SP				"Ajustes"
#define PRINTING_PAUSE_SP					"Pausar"
#define PRINTING_TEMP_SP					"Temp."
#define PRINTING_CHANGESPEED_SP				"Velocidad"
#define PRINTING_RESUME_SP					"Resumir"
#define PRINTING_STOP_SP					"Detener"
#define PRINTING_MORE_SP					"Más"
#define PRINTING_EXTRUDER_SP				"Extrusión"
#define PRINTING_MOVE_SP                    "Mover"

#define EXTRUDER_SPEED_SP					"Extrusión"
#define MOVE_SPEED_SP						"Mover"
#define EXTRUDER_SPEED_STATE_SP				"Extrusión"
#define MOVE_SPEED_STATE_SP					"Movimiento"
#define STEP_1PERCENT_SP					"1%"
#define STEP_5PERCENT_SP					"5%"
#define STEP_10PERCENT_SP					"10%"


#define TITLE_READYPRINT_SP						"Inicio"
#define TITLE_PREHEAT_SP						"Precalentar"
#define TITLE_MOVE_SP					        "Mover"
#define TITLE_HOME_SP						"Origen"
#define TITLE_EXTRUDE_SP						"Extrusión"
#define TITLE_LEVELING_SP						"Leveling"
#define TITLE_SET_SP							"Config"
#define TITLE_MORE_SP							"Más"
#define TITLE_CHOOSEFILE_SP						"Imprimir"
#define TITLE_PRINTING_SP						"Imprimir"
#define TITLE_OPERATION_SP						"Ajustes"
#define TITLE_ADJUST_SP							"Temp."
#define	TITLE_WIRELESS_SP						"Wireless"
#define	TITLE_FILAMENT_SP						"Filamento"
#define TITLE_ABOUT_SP							"Acerca"
#define TITLE_FAN_SP							"Vent."
#define TITLE_LANGUAGE_SP						"Language"
#define TITLE_PAUSE_SP							"Pausar"
#define TITLE_CHANGESPEED_SP				    "Velocidad"
#define TILE_TOOL_SP						    "Ajustes"
#define TITLE_CLOUD_TEXT_SP				        "Cloud"
#define TITLE_DIALOG_CONFIRM_SP				"Confirmar"
#define TITLE_FILESYS_SP								"Puerto"

#define AUTO_SHUTDOWN_SP					"Auto"
#define MANUAL_SHUTDOWN_SP					"manual"

#define DIALOG_CONFIRM_SP					"Confirmar"
#define DIALOG_CANCLE_SP					"Cancelar"
#define DIALOG_OK_SP						"OK"
#define DIALOG_RESET_SP						"Resetear"
#define DIALOG_RETRY_SP						"Reintentar"
#define DIALOG_DISABLE_SP					"Desactivar"
#define DIALOG_PRINT_MODEL_SP				"¿Está seguro?"
#define DIALOG_CANCEL_PRINT_SP				"¿Está seguro que desea\n detener la impresión?"

#define DIALOG_RETRY_SP						"Reintentar"
#define DIALOG_STOP_SP						"Stop"
#define DIALOG_REPRINT_FROM_BREAKPOINT_SP	"Reprint from breakpoint?"
#define DIALOG_UNBIND_PRINTER_SP			"Unbind the printer?"
#define DIALOG_ERROR_TIPS1_SP				"Error:archivo no encontrado, \npor favor insertar SD o disco USB."
#define DIALOG_ERROR_TIPS2_SP				"error:transacción fallida, \nconfigurar  baudrate del \ndisplay para la placa base!"
#define DIALOG_ERROR_TIPS3_SP				"Error : nombre de archivo o \nruta demasiado largo!"
#define DIALOG_CLOSE_MACHINE_SP             "Closing machine......"
#define DIALOG_UNBIND_PRINTER_SP            "Unbind the printer?"
#define DIALOG_WIFI_ENABLE_SP            "Enable"
#define DIALOG_WIFI_DISABLE_SP           "Disable"
#define DIALOG_TEXT_WIFI_ENABLE_SP       "Enable"
#define DIALOG_TEXT_WIFI_DISABLE_SP      "Disable"

#define DIALOG_TEXT_NO_TEMP_TIPS_SP     "Sin temperatura objetivo, \nelija la temperatura predeterminada \no configure la temperatura"
#define DIALOG_TEXT_DEFAULT_TEMP_SP     "Default"
#define DIALOG_TEXT_SETTING_TEMP_SP     "Ajuste"

#if 0
//****************希腊语***************************//
#define TOOL_TEXT_GR		"Tool"
#define PREHEAT_TEXT_GR "Preheat"
#define	MOVE_TEXT_GR		"Move"
#define HOME_TEXT_GR  "Home"
#define PRINT_TEXT_GR		"Print"
#define EXTRUDE_TEXT_GR "Extrude"
#define LEVELING_TEXT_GR "Leveling"
#define AUTO_LEVELING_TEXT_GR "AutoLevel"
#define SET_TEXT_GR		"Set"
#define MORE_TEXT_GR     "More"

#define ADD_TEXT_GR			"ADD"
#define DEC_TEXT_GR			"DEC"
#define EXTRUDER_1_TEXT_GR		"Extruder1"
#define EXTRUDER_2_TEXT_GR		"Extruder2"
#define HEATBED_TEXT_GR			"HeatBed"
#define TEXT_1C_GR						"1℃"
#define TEXT_5C_GR						"5℃"
#define TEXT_10C_GR					"10℃"
#define CLOSE_TEXT_GR				"Close"

#define BACK_TEXT_GR					"Back"

#define AXIS_X_ADD_TEXT_GR				"X+"
#define AXIS_X_DEC_TEXT_GR				"X-"
#define AXIS_Y_ADD_TEXT_GR				"Y+"
#define AXIS_Y_DEC_TEXT_GR				"Y-"
#define AXIS_Z_ADD_TEXT_GR				"Z+"
#define AXIS_Z_DEC_TEXT_GR				"Z-"
#define TEXT_01MM_GR							"0.1mm"
#define TEXT_1MM_GR							"1mm"
#define TEXT_10MM_GR							"10mm"

#define HOME_X_TEXT_GR						"X"
#define HOME_Y_TEXT_GR						"Y"
#define HOME_Z_TEXT_GR						"Z"
#define HOME_ALL_TEXT_GR					"Home"

#define PAGE_UP_TEXT_GR					"Page up"
#define PAGE_DOWN_TEXT_GR				"Page down"

#define EXTRUDER_IN_TEXT_GR		"IN"
#define EXTRUDER_OUT_TEXT_GR		"OUT"
#define EXTRUDE_1MM_TEXT_GR			"1mm"
#define EXTRUDE_5MM_TEXT_GR			"5mm"
#define EXTRUDE_10MM_TEXT_GR		"10mm"
#define EXTRUDE_LOW_SPEED_TEXT_GR		"LOW"
#define EXTRUDE_MEDIUM_SPEED_TEXT_GR	"Medium"
#define EXTRUDE_HIGH_SPEED_TEXT_GR		"High"

#define LEVELING_POINT1_TEXT_GR				"Point1"
#define LEVELING_POINT2_TEXT_GR				"Point2"
#define LEVELING_POINT3_TEXT_GR			"Point3"
#define LEVELING_POINT4_TEXT_GR				"Point4"
#define LEVELING_POINT5_TEXT_GR				"Point5"

#define FILESYS_TEXT_GR								"FileSys"
#define WIFI_TEXT_GR									"WIFI"
#define FAN_TEXT_GR										"Fan"
#define ABOUT_TEXT_GR									"About"
#define BREAK_POINT_TEXT_GR						"Continu"
#define FILAMENT_TEXT_GR							"Filament"
#define LANGUAGE_TEXT_GR							"Language"
#define MOTOR_OFF_TEXT_GR							"Motor-off"
#define SHUTDOWN_TEXT_GR							"Shutdown"

#define U_DISK_TEXT_GR								"U Disk"
#define SD_CARD_TEXT_GR								"SDCard"
#define WIFI_NAME_TEXT_GR							"WIFI:%s"
#define WIFI_KEY_TEXT_GR							"KEY:%s"
#define WIFI_IP_TEXT_GR								"IP:%s"
#define WIFI_AP_TEXT_GR								"STATE: AP"
#define WIFI_STA_TEXT_GR							"STATE: STA"
#define WIFI_CONNECTED_TEXT_GR				"CONNECTED"
#define WIFI_DISCONNECTED_TEXT_GR			"DISCONNECTED"
#define WIFI_EXCEPTION_TEXT_GR				"EXCEPTION"
#define CLOUD_TEXT_GR								"Cloud"
#define CLOUD_BIND_GR								"Bind"
#define CLOUD_UNBIND_GR							"Unbind"
#define CLOUD_UNBINDING_GR					"Unbinding"
#define CLOUD_DISCONNECTED_GR				"Disconnected"
#define CLOUD_UNBINDED_GR						"Unbinded"
#define CLOUD_BINDED_GR							"Binded"
#define CLOUD_DISABLE_GR						"Disable"

#define FAN_ADD_TEXT_GR								"ADD"
#define FAN_DEC_TEXT_GR								"DEC"
#define FAN_OPEN_TEXT_GR							"100%"
#define FAN_HALF_TEXT_GR							"50%"
#define FAN_CLOSE_TEXT_GR							"Close"
#define FAN_TIPS1_TEXT_GR								"FAN\n%d"
#define FAN_TIPS2_TEXT_GR								"FAN\nClose"

#define FILAMENT_IN_TEXT_GR						"In"
#define FILAMENT_OUT_TEXT_GR					"Out"
#define FILAMENT_EXT0_TEXT_GR					"E1"
#define FILAMENT_EXT1_TEXT_GR					"E2"
#define FILAMENT_HEAT_TEXT_GR					"Preheat"					
#define FILAMENT_STOP_TEXT_GR					"Stop"
#define FILAMENT_CHANGE_TEXT_GR				"Filament replace"
#define FILAMENT_TIPS2_TEXT_GR				"T:%d℃/%d℃"
#define FILAMENT_TIPS3_TEXT_GR				"loading..."
#define FILAMENT_TIPS4_TEXT_GR				"unloading..."
#define FILAMENT_TIPS5_TEXT_GR				"Temp is too low to go,please heat"
#define FILAMENT_TIPS6_TEXT_GR				"Completed"

#define PRE_HEAT_EXT_TEXT_GR						"E%d\n%d℃/%d℃"
#define PRE_HEAT_BED_TEXT_GR						"Bed\n%d℃/%d℃"

#define FILE_LOADING_GR				"Loading......"
#define NO_FILE_AND_CHECK_GR					"No files found!\nCheck the file system configuration!"
#define NO_FILE_GR					"No files found!"



#define EXTRUDER_TEMP_TEXT_GR				"T:%d℃"
#define EXTRUDER_E_LENGTH1_TEXT_GR   "E%d:%dmm"
#define EXTRUDER_E_LENGTH2_TEXT_GR   "E%d:%dcm"
#define EXTRUDER_E_LENGTH3_TEXT_GR   "E%d:%dm"

#define ABOUT_TYPE_TEXT_GR							"Type: MKS TFT"
#define ABOUT_VERSION_TEXT_GR					"Version: 3.0.0"
#define ABOUT_WIFI_TEXT_GR							"WIFI:"

#define PRINTING_OPERATION_GR					"Operation"
#define PRINTING_PAUSE_GR						"Pause"
#define PRINTING_TEMP_GR								"Temp."
#define PRINTING_CHANGESPEED_GR				"Speed"
#define PRINTING_RESUME_GR						"Resume"
#define PRINTING_STOP_GR								"Stop"
#define PRINTING_MORE_GR								"More"
#define PRINTING_EXTRUDER_GR					"Extruder"

#define EXTRUDER_SPEED_GR							"Extrude"
#define MOVE_SPEED_GR									"Move"
#define EXTRUDER_SPEED_STATE_GR							"Extrude Speed\n%d%%"
#define MOVE_SPEED_STATE_GR									"Move Speed\n%d%%"
#define STEP_1PERCENT_GR										"1%"
#define STEP_5PERCENT_GR										"5%"
#define STEP_10PERCENT_GR										"10%"

#define TILE_READYPRINT_GR							"ReadyPrint"
#define TILE_CHOOSEFILE_GR							"ChooseFile"
#define TILE_PRINTING_GR								"Printing"
#define TILE_OPERATION_GR								"Operation"
#define TILE_ADJUST_GR									"Adjust"
#define	TILE_WIRELESS_GR								"Wireless"
#define TITLE_CLOUD_TEXT_GR				        "Cloud"
#define TITILE_DIALOG_CONFIRM_GR				"Confirm"

#define AUTO_SHUTDOWN_GR								"Auto"
#define MANUAL_SHUTDOWN_GR							"Manual"

#define DIALOG_CONFIRM_GR							"Confirm"
#define DIALOG_CANCLE_GR							"Cancel"
#define DIALOG_OK_GR									"OK"
#define DIALOG_RESET_GR								"Reset"
#define DIALOG_RETRY_GR								"Retry"
#define DIALOG_DISABLE_GR							"Disable"
#define DIALOG_PRINT_MODEL_GR					"Print this model?"
#define DIALOG_CANCEL_PRINT_GR				"Stop print?"
#define DIALOG_STOP_GR									"Stop"
#define DIALOG_REPRINT_FROM_BREAKPOINT_GR	"Reprint from breakpoint?"
#define DIALOG_UNBIND_PRINTER_GR						"Unbind the printer?"
#define DIALOG_ERROR_TIPS1_GR								"error:no file,please check it again."
#define DIALOG_ERROR_TIPS2_GR								"error:transaction failed.please check display baudrate \nwhether as the same as mainboard!"
#define DIALOG_ERROR_TIPS3_GR								"error:file name or path is too long!"
#define DIALOG_CLOSE_MACHINE_GR             "Closing machine......"
#define DIALOG_UNBIND_PRINTER_GR            "Unbind the printer?"
#define DIALOG_WIFI_ENABLE_GR            "Enable"
#define DIALOG_WIFI_DISABLE_GR           "Disable"
#define DIALOG_TEXT_WIFI_ENABLE_GR       "Enable"
#define DIALOG_TEXT_WIFI_DISABLE_GR      "Disable"
//****************土耳其语***************************//
#define TOOL_TEXT_TU		"Tool"
#define PREHEAT_TEXT_TU "Preheat"
#define	MOVE_TEXT_TU		"Move"
#define HOME_TEXT_TU  "Home"
#define PRINT_TEXT_TU		"Print"
#define EXTRUDE_TEXT_TU "Extrude"
#define LEVELING_TEXT_TU "Leveling"
#define AUTO_LEVELING_TEXT_TU "AutoLevel"
#define SET_TEXT_TU		"Set"
#define MORE_TEXT_TU     "More"

#define ADD_TEXT_TU			"ADD"
#define DEC_TEXT_TU			"DEC"
#define EXTRUDER_1_TEXT_TU		"Extruder1"
#define EXTRUDER_2_TEXT_TU		"Extruder2"
#define HEATBED_TEXT_TU			"HeatBed"
#define TEXT_1C_TU						"1℃"
#define TEXT_5C_TU						"5℃"
#define TEXT_10C_TU					"10℃"
#define CLOSE_TEXT_TU				"Close"

#define BACK_TEXT_TU					"Back"

#define AXIS_X_ADD_TEXT_TU				"X+"
#define AXIS_X_DEC_TEXT_TU				"X-"
#define AXIS_Y_ADD_TEXT_TU				"Y+"
#define AXIS_Y_DEC_TEXT_TU				"Y-"
#define AXIS_Z_ADD_TEXT_TU				"Z+"
#define AXIS_Z_DEC_TEXT_TU				"Z-"
#define TEXT_01MM_TU							"0.1mm"
#define TEXT_1MM_TU							"1mm"
#define TEXT_10MM_TU							"10mm"

#define HOME_X_TEXT_TU						"X"
#define HOME_Y_TEXT_TU						"Y"
#define HOME_Z_TEXT_TU						"Z"
#define HOME_ALL_TEXT_TU					"Home"

#define PAGE_UP_TEXT_TU					"Page up"
#define PAGE_DOWN_TEXT_TU				"Page down"

#define EXTRUDER_IN_TEXT_TU		"IN"
#define EXTRUDER_OUT_TEXT_TU		"OUT"
#define EXTRUDE_1MM_TEXT_TU			"1mm"
#define EXTRUDE_5MM_TEXT_TU			"5mm"
#define EXTRUDE_10MM_TEXT_TU		"10mm"
#define EXTRUDE_LOW_SPEED_TEXT_TU		"LOW"
#define EXTRUDE_MEDIUM_SPEED_TEXT_TU	"Medium"
#define EXTRUDE_HIGH_SPEED_TEXT_TU		"High"

#define LEVELING_POINT1_TEXT_TU				"Point1"
#define LEVELING_POINT2_TEXT_TU				"Point2"
#define LEVELING_POINT3_TEXT_TU			"Point3"
#define LEVELING_POINT4_TEXT_TU				"Point4"
#define LEVELING_POINT5_TEXT_TU				"Point5"

#define FILESYS_TEXT_TU								"FileSys"
#define WIFI_TEXT_TU									"WIFI"
#define FAN_TEXT_TU										"Fan"
#define ABOUT_TEXT_TU									"About"
#define BREAK_POINT_TEXT_TU						"Continu"
#define FILAMENT_TEXT_TU							"Filament"
#define LANGUAGE_TEXT_TU							"Language"
#define MOTOR_OFF_TEXT_TU							"Motor-off"
#define SHUTDOWN_TEXT_TU							"Shutdown"

#define U_DISK_TEXT_TU								"U Disk"
#define SD_CARD_TEXT_TU								"SDCard"
#define WIFI_NAME_TEXT_TU							"WIFI:%s"
#define WIFI_KEY_TEXT_TU							"KEY:%s"
#define WIFI_IP_TEXT_TU								"IP:%s"
#define WIFI_AP_TEXT_TU								"STATE: AP"
#define WIFI_STA_TEXT_TU							"STATE: STA"
#define WIFI_CONNECTED_TEXT_TU				"CONNECTED"
#define WIFI_DISCONNECTED_TEXT_TU			"DISCONNECTED"
#define WIFI_EXCEPTION_TEXT_TU				"EXCEPTION"
#define CLOUD_TEXT_TU								"Cloud"
#define CLOUD_BIND_TU								"Bind"
#define CLOUD_UNBIND_TU							"Unbind"
#define CLOUD_UNBINDING_TU					"Unbinding"
#define CLOUD_DISCONNECTED_TU				"Disconnected"
#define CLOUD_UNBINDED_TU						"Unbinded"
#define CLOUD_BINDED_TU							"Binded"
#define CLOUD_DISABLE_TU						"Disable"

#define FAN_ADD_TEXT_TU								"ADD"
#define FAN_DEC_TEXT_TU								"DEC"
#define FAN_OPEN_TEXT_TU							"100%"
#define FAN_HALF_TEXT_TU							"50%"
#define FAN_CLOSE_TEXT_TU							"Close"
#define FAN_TIPS1_TEXT_TU								"FAN\n%d"
#define FAN_TIPS2_TEXT_TU								"FAN\nClose"

#define FILAMENT_IN_TEXT_TU						"In"
#define FILAMENT_OUT_TEXT_TU					"Out"
#define FILAMENT_EXT0_TEXT_TU					"E1"
#define FILAMENT_EXT1_TEXT_TU					"E2"
#define FILAMENT_HEAT_TEXT_TU					"Preheat"					
#define FILAMENT_STOP_TEXT_TU					"Stop"
#define FILAMENT_CHANGE_TEXT_TU				"Filament replace"
#define FILAMENT_TIPS2_TEXT_TU				"T:%d℃/%d℃"
#define FILAMENT_TIPS3_TEXT_TU				"loading..."
#define FILAMENT_TIPS4_TEXT_TU				"unloading..."
#define FILAMENT_TIPS5_TEXT_TU				"Temp is too low to go,please heat"
#define FILAMENT_TIPS6_TEXT_TU				"Completed"

#define PRE_HEAT_EXT_TEXT_TU						"E%d\n%d℃/%d℃"
#define PRE_HEAT_BED_TEXT_TU						"Bed\n%d℃/%d℃"

#define FILE_LOADING_TU				"Loading......"
#define NO_FILE_AND_CHECK_TU					"No files found!\nCheck the file system configuration!"
#define NO_FILE_TU					"No files found!"



#define EXTRUDER_TEMP_TEXT_TU				"T:%d℃"
#define EXTRUDER_E_LENGTH1_TEXT_TU   "E%d:%dmm"
#define EXTRUDER_E_LENGTH2_TEXT_TU   "E%d:%dcm"
#define EXTRUDER_E_LENGTH3_TEXT_TU   "E%d:%dm"

#define ABOUT_TYPE_TEXT_TU							"Type: MKS TFT"
#define ABOUT_VERSION_TEXT_TU					"Version: 3.0.0"
#define ABOUT_WIFI_TEXT_TU							"WIFI:"

#define PRINTING_OPERATION_TU					"Operation"
#define PRINTING_PAUSE_TU						"Pause"
#define PRINTING_TEMP_TU								"Temp."
#define PRINTING_CHANGESPEED_TU				"Speed"
#define PRINTING_RESUME_TU						"Resume"
#define PRINTING_STOP_TU								"Stop"
#define PRINTING_MORE_TU								"More"
#define PRINTING_EXTRUDER_TU					"Extruder"

#define EXTRUDER_SPEED_TU							"Extrude"
#define MOVE_SPEED_TU									"Move"
#define EXTRUDER_SPEED_STATE_TU							"Extrude Speed\n%d%%"
#define MOVE_SPEED_STATE_TU									"Move Speed\n%d%%"
#define STEP_1PERCENT_TU										"1%"
#define STEP_5PERCENT_TU										"5%"
#define STEP_10PERCENT_TU										"10%"

#define TILE_READYPRINT_TU							"ReadyPrint"
#define TILE_CHOOSEFILE_TU							"ChooseFile"
#define TILE_PRINTING_TU								"Printing"
#define TILE_OPERATION_TU								"Operation"
#define TILE_ADJUST_TU									"Adjust"
#define	TILE_WIRELESS_TU								"Wireless"
#define TITLE_CLOUD_TEXT_TU				        "Cloud"
#define TITILE_DIALOG_CONFIRM_TU				"Confirm"

#define AUTO_SHUTDOWN_TU								"Auto"
#define MANUAL_SHUTDOWN_TU							"Manual"

#define DIALOG_CONFIRM_TU							"Confirm"
#define DIALOG_CANCLE_TU							"Cancel"
#define DIALOG_OK_TU									"OK"
#define DIALOG_RESET_TU								"Reset"
#define DIALOG_RETRY_TU								"Retry"
#define DIALOG_DISABLE_TU							"Disable"
#define DIALOG_PRINT_MODEL_TU					"Print this model?"
#define DIALOG_CANCEL_PRINT_TU				"Stop print?"
#define DIALOG_RETRY_TU									"Retry"
#define DIALOG_STOP_TU									"Stop"
#define DIALOG_REPRINT_FROM_BREAKPOINT_TU	"Reprint from breakpoint?"
#define DIALOG_UNBIND_PRINTER_TU						"Unbind the printer?"
#define DIALOG_ERROR_TIPS1_TU								"error:no file,please check it again."
#define DIALOG_ERROR_TIPS2_TU								"error:transaction failed.please check display baudrate \nwhether as the same as mainboard!"
#define DIALOG_ERROR_TIPS3_TU								"error:file name or path is too long!"
#define DIALOG_CLOSE_MACHINE_TU             "Closing machine......"
#define DIALOG_UNBIND_PRINTER_TU            "Unbind the printer?"
#define DIALOG_WIFI_ENABLE_TU            "Enable"
#define DIALOG_WIFI_DISABLE_TU           "Disable"
#define DIALOG_TEXT_WIFI_ENABLE_TU       "Enable"
#define DIALOG_TEXT_WIFI_DISABLE_TU      "Disable"
//****************韩语***************************//
#define TOOL_TEXT_KR		"Tool"
#define PREHEAT_TEXT_KR "Preheat"
#define	MOVE_TEXT_KR		"Move"
#define HOME_TEXT_KR  "Home"
#define PRINT_TEXT_KR		"Print"
#define EXTRUDE_TEXT_KR "Extrude"
#define LEVELING_TEXT_KR "Leveling"
#define AUTO_LEVELING_TEXT_KR "AutoLevel"
#define SET_TEXT_KR		"Set"
#define MORE_TEXT_KR     "More"

#define ADD_TEXT_KR			"ADD"
#define DEC_TEXT_KR			"DEC"
#define EXTRUDER_1_TEXT_KR		"Extruder1"
#define EXTRUDER_2_TEXT_KR		"Extruder2"
#define HEATBED_TEXT_KR			"HeatBed"
#define TEXT_1C_KR						"1℃"
#define TEXT_5C_KR						"5℃"
#define TEXT_10C_KR					"10℃"
#define CLOSE_TEXT_KR				"Close"

#define BACK_TEXT_KR					"Back"

#define AXIS_X_ADD_TEXT_KR				"X+"
#define AXIS_X_DEC_TEXT_KR				"X-"
#define AXIS_Y_ADD_TEXT_KR				"Y+"
#define AXIS_Y_DEC_TEXT_KR				"Y-"
#define AXIS_Z_ADD_TEXT_KR				"Z+"
#define AXIS_Z_DEC_TEXT_KR				"Z-"
#define TEXT_01MM_KR							"0.1mm"
#define TEXT_1MM_KR							"1mm"
#define TEXT_10MM_KR							"10mm"

#define HOME_X_TEXT_KR						"X"
#define HOME_Y_TEXT_KR						"Y"
#define HOME_Z_TEXT_KR						"Z"
#define HOME_ALL_TEXT_KR					"Home"

#define PAGE_UP_TEXT_KR					"Page up"
#define PAGE_DOWN_TEXT_KR				"Page down"

#define EXTRUDER_IN_TEXT_KR		"IN"
#define EXTRUDER_OUT_TEXT_KR		"OUT"
#define EXTRUDE_1MM_TEXT_KR			"1mm"
#define EXTRUDE_5MM_TEXT_KR			"5mm"
#define EXTRUDE_10MM_TEXT_KR		"10mm"
#define EXTRUDE_LOW_SPEED_TEXT_KR		"LOW"
#define EXTRUDE_MEDIUM_SPEED_TEXT_KR	"Medium"
#define EXTRUDE_HIGH_SPEED_TEXT_KR		"High"

#define LEVELING_POINT1_TEXT_KR				"Point1"
#define LEVELING_POINT2_TEXT_KR				"Point2"
#define LEVELING_POINT3_TEXT_KR			"Point3"
#define LEVELING_POINT4_TEXT_KR				"Point4"
#define LEVELING_POINT5_TEXT_KR				"Point5"

#define FILESYS_TEXT_KR								"FileSys"
#define WIFI_TEXT_KR									"WIFI"
#define FAN_TEXT_KR										"Fan"
#define ABOUT_TEXT_KR									"About"
#define BREAK_POINT_TEXT_KR						"Continu"
#define FILAMENT_TEXT_KR							"Filament"
#define LANGUAGE_TEXT_KR							"Language"
#define MOTOR_OFF_TEXT_KR							"Motor-off"
#define SHUTDOWN_TEXT_KR							"Shutdown"

#define U_DISK_TEXT_KR								"U Disk"
#define SD_CARD_TEXT_KR								"SDCard"
#define WIFI_NAME_TEXT_KR							"WIFI:%s"
#define WIFI_KEY_TEXT_KR							"KEY:%s"
#define WIFI_IP_TEXT_KR								"IP:%s"
#define WIFI_AP_TEXT_KR								"STATE: AP"
#define WIFI_STA_TEXT_KR							"STATE: STA"
#define WIFI_CONNECTED_TEXT_KR				"CONNECTED"
#define WIFI_DISCONNECTED_TEXT_KR			"DISCONNECTED"
#define WIFI_EXCEPTION_TEXT_KR				"EXCEPTION"
#define CLOUD_TEXT_KR								"Cloud"
#define CLOUD_BIND_KR								"Bind"
#define CLOUD_UNBIND_KR							"Unbind"
#define CLOUD_UNBINDING_KR					"Unbinding"
#define CLOUD_DISCONNECTED_KR				"Disconnected"
#define CLOUD_UNBINDED_KR						"Unbinded"
#define CLOUD_BINDED_KR							"Binded"
#define CLOUD_DISABLE_KR						"Disable"

#define FAN_ADD_TEXT_KR								"ADD"
#define FAN_DEC_TEXT_KR								"DEC"
#define FAN_OPEN_TEXT_KR							"100%"
#define FAN_HALF_TEXT_KR							"50%"
#define FAN_CLOSE_TEXT_KR							"Close"
#define FAN_TIPS1_TEXT_KR								"FAN\n%d"
#define FAN_TIPS2_TEXT_KR								"FAN\nClose"

#define FILAMENT_IN_TEXT_KR						"In"
#define FILAMENT_OUT_TEXT_KR					"Out"
#define FILAMENT_EXT0_TEXT_KR					"E1"
#define FILAMENT_EXT1_TEXT_KR					"E2"
#define FILAMENT_HEAT_TEXT_KR					"Preheat"					
#define FILAMENT_STOP_TEXT_KR					"Stop"
#define FILAMENT_CHANGE_TEXT_KR				"Filament replace"
#define FILAMENT_TIPS2_TEXT_KR				"T:%d℃/%d℃"
#define FILAMENT_TIPS3_TEXT_KR				"loading..."
#define FILAMENT_TIPS4_TEXT_KR				"unloading..."
#define FILAMENT_TIPS5_TEXT_KR				"Temp is too low to go,please heat"
#define FILAMENT_TIPS6_TEXT_KR				"Completed"

#define PRE_HEAT_EXT_TEXT_KR						"E%d\n%d℃/%d℃"
#define PRE_HEAT_BED_TEXT_KR						"Bed\n%d℃/%d℃"

#define FILE_LOADING_KR				"Loading......"
#define NO_FILE_AND_CHECK_KR					"No files found!\nCheck the file system configuration!"
#define NO_FILE_KR					"No files found!"



#define EXTRUDER_TEMP_TEXT_KR				"T:%d℃"
#define EXTRUDER_E_LENGTH1_TEXT_KR   "E%d:%dmm"
#define EXTRUDER_E_LENGTH2_TEXT_KR   "E%d:%dcm"
#define EXTRUDER_E_LENGTH3_TEXT_KR   "E%d:%dm"

#define ABOUT_TYPE_TEXT_KR							"Type: MKS TFT"
#define ABOUT_VERSION_TEXT_KR					"Version: 3.0.0"
#define ABOUT_WIFI_TEXT_KR							"WIFI:"

#define PRINTING_OPERATION_KR					"Operation"
#define PRINTING_PAUSE_KR						"Pause"
#define PRINTING_TEMP_KR								"Temp."
#define PRINTING_CHANGESPEED_KR				"Speed"
#define PRINTING_RESUME_KR						"Resume"
#define PRINTING_STOP_KR								"Stop"
#define PRINTING_MORE_KR								"More"
#define PRINTING_EXTRUDER_KR					"Extruder"

#define EXTRUDER_SPEED_KR							"Extrude"
#define MOVE_SPEED_KR									"Move"
#define EXTRUDER_SPEED_STATE_KR							"Extrude Speed\n%d%%"
#define MOVE_SPEED_STATE_KR									"Move Speed\n%d%%"
#define STEP_1PERCENT_KR										"1%"
#define STEP_5PERCENT_KR										"5%"
#define STEP_10PERCENT_KR										"10%"

#define TILE_READYPRINT_KR							"ReadyPrint"
#define TILE_CHOOSEFILE_KR							"ChooseFile"
#define TILE_PRINTING_KR								"Printing"
#define TILE_OPERATION_KR								"Operation"
#define TILE_ADJUST_KR									"Adjust"
#define	TILE_WIRELESS_KR								"Wireless"
#define TITLE_CLOUD_TEXT_KR				        "Cloud"
#define TITILE_DIALOG_CONFIRM_KR				"Confirm"

#define AUTO_SHUTDOWN_KR								"Auto"
#define MANUAL_SHUTDOWN_KR							"Manual"

#define DIALOG_CONFIRM_KR							"Confirm"
#define DIALOG_CANCLE_KR							"Cancel"
#define DIALOG_OK_KR									"OK"
#define DIALOG_RESET_KR								"Reset"
#define DIALOG_RETRY_KR								"Retry"
#define DIALOG_DISABLE_KR							"Disable"
#define DIALOG_PRINT_MODEL_KR					"Print this model?"
#define DIALOG_CANCEL_PRINT_KR				"Stop print?"
#define DIALOG_STOP_KR									"Stop"
#define DIALOG_REPRINT_FROM_BREAKPOINT_KR	"Reprint from breakpoint?"
#define DIALOG_UNBIND_PRINTER_KR						"Unbind the printer?"
#define DIALOG_ERROR_TIPS1_KR								"error:no file,please check it again."
#define DIALOG_ERROR_TIPS2_KR								"error:transaction failed.please check display baudrate \nwhether as the same as mainboard!"
#define DIALOG_ERROR_TIPS3_KR								"error:file name or path is too long!"
#define DIALOG_CLOSE_MACHINE_KR             "Closing machine......"
#define DIALOG_UNBIND_PRINTER_KR            "Unbind the printer?"
#define DIALOG_WIFI_ENABLE_KR            "Enable"
#define DIALOG_WIFI_DISABLE_KR           "Disable"
#define DIALOG_TEXT_WIFI_ENABLE_KR       "Enable"
#define DIALOG_TEXT_WIFI_DISABLE_KR      "Disable"
#endif
//****************意大利语***************************//
#define TOOL_TEXT_IT		"Strumento"
#define PREHEAT_TEXT_IT         "Pprerisc"
#define	MOVE_TEXT_IT		    "Muovi"
#define HOME_TEXT_IT            "Home"
#define PRINT_TEXT_IT		    "Stampa"
#define EXTRUDE_TEXT_IT         "Estrude"
#define LEVELING_TEXT_IT        "Leveling"
#define AUTO_LEVELING_TEXT_IT   "AutoLevel"
#define SET_TEXT_IT		        "Imposta"
#define MORE_TEXT_IT            "Di più"

#define ADD_TEXT_IT			    "Aumentare"
#define DEC_TEXT_IT			    "Ridurre"
#define EXTRUDER_1_TEXT_IT		"Estrude1"
#define EXTRUDER_2_TEXT_IT		"Estrude2"
#define HEATBED_TEXT_IT			"Piano"
#define TEXT_1C_IT				"1℃"
#define TEXT_5C_IT				"5℃"
#define TEXT_10C_IT				"10℃"
#define CLOSE_TEXT_IT			"Spento"

#define BACK_TEXT_IT					"Indietro"

#define AXIS_X_ADD_TEXT_IT				"X+"
#define AXIS_X_DEC_TEXT_IT				"X-"
#define AXIS_Y_ADD_TEXT_IT				"Y+"
#define AXIS_Y_DEC_TEXT_IT				"Y-"
#define AXIS_Z_ADD_TEXT_IT				"Z+"
#define AXIS_Z_DEC_TEXT_IT				"Z-"
#define TEXT_01MM_IT					"0.1mm"
#define TEXT_1MM_IT						"1mm"
#define TEXT_10MM_IT					"10mm"

#define HOME_X_TEXT_IT					"X"
#define HOME_Y_TEXT_IT					"Y"
#define HOME_Z_TEXT_IT					"Z"
#define HOME_ALL_TEXT_IT				"All"

#define PAGE_UP_TEXT_IT					"Pagina su"
#define PAGE_DOWN_TEXT_IT				"Pagina giù"

#define EXTRUDER_IN_TEXT_IT		    "Estru"
#define EXTRUDER_OUT_TEXT_IT		    "Ritra"
#define EXTRUDE_1MM_TEXT_IT			    "1mm"
#define EXTRUDE_5MM_TEXT_IT			    "5mm"
#define EXTRUDE_10MM_TEXT_IT		    "10mm"
#define EXTRUDE_LOW_SPEED_TEXT_IT		"Bassa"
#define EXTRUDE_MEDIUM_SPEED_TEXT_IT	"Media"
#define EXTRUDE_HIGH_SPEED_TEXT_IT		"Alta"

#define LEVELING_POINT1_TEXT_IT				"Primo"
#define LEVELING_POINT2_TEXT_IT				"Secondo"
#define LEVELING_POINT3_TEXT_IT			    "Terzo"
#define LEVELING_POINT4_TEXT_IT				"Quarto"
#define LEVELING_POINT5_TEXT_IT				"Quinto"

#define FILESYS_TEXT_IT						"FileSys"
#define WIFI_TEXT_IT					    "WIFI"
#define FAN_TEXT_IT							"Ventola"
#define ABOUT_TEXT_IT						"Circa"
#define BREAK_POINT_TEXT_IT					"Continua"
#define FILAMENT_TEXT_IT					"Filamento"
#define LANGUAGE_TEXT_IT					"Lingua"
#define MOTOR_OFF_TEXT_IT					"Motor off"
#define SHUTDOWN_TEXT_IT					"Spento"

#define U_DISK_TEXT_IT						"USB"
#define SD_CARD_TEXT_IT						"SD"
#define WIFI_NAME_TEXT_IT					"WIFI:"
#define WIFI_KEY_TEXT_IT					"KEY:"
#define WIFI_IP_TEXT_IT						"IP:"
#define WIFI_AP_TEXT_IT						"Stato: AP"
#define WIFI_STA_TEXT_IT					"Stato: STA"
#define WIFI_CONNECTED_TEXT_IT				"Connesso"
#define WIFI_DISCONNECTED_TEXT_IT			"Disconnesso"
#define WIFI_EXCEPTION_TEXT_IT				"Eccezione"
#define CLOUD_TEXT_IT						"Cloud"
#define CLOUD_BIND_IT						"Legato"
#define CLOUD_UNBIND_IT						"Libero"
#define CLOUD_DISCONNECTED_IT				"Disconnesso"
#define CLOUD_UNBINDING_IT					"Libero"
#define CLOUD_UNBINDED_IT					"Sciolto"
#define CLOUD_BINDED_IT						"Legato"
#define CLOUD_DISABLE_IT					"Disable"

#define FAN_ADD_TEXT_IT						"Aumentare"
#define FAN_DEC_TEXT_IT						"Ridurre"
#define FAN_OPEN_TEXT_IT					"100%"
#define FAN_HALF_TEXT_IT					"50%"
#define FAN_CLOSE_TEXT_IT					"Spento"
#define FAN_TIPS1_TEXT_IT					"Ventola"
#define FAN_TIPS2_TEXT_IT					"Ventola\n0"

#define FILAMENT_IN_TEXT_IT					"Inser"
#define FILAMENT_OUT_TEXT_IT				"Estra"
#define FILAMENT_EXT0_TEXT_IT				"E1"
#define FILAMENT_EXT1_TEXT_IT				"E2"
#define FILAMENT_HEAT_TEXT_IT			    "Preriscaldamento"					
#define FILAMENT_STOP_TEXT_IT				"Stop"
#define FILAMENT_CHANGE_TEXT_IT				"Filamento"
#define FILAMENT_TIPS2_TEXT_IT				"T:"
#define FILAMENT_TIPS3_TEXT_IT				"Inserimento del filamento..."
#define FILAMENT_TIPS4_TEXT_IT				"Estrazione del filamento..."
#define FILAMENT_TIPS5_TEXT_IT				"Temp is too low to go,please heat"
#define FILAMENT_TIPS6_TEXT_IT				"Completato"
#define FILAMENT_CHANGE_TEXT_IT				"Please click <Load> \nor <unload>."
#define FILAMENT_DIALOG_LOAD_HEAT_TIPS_IT		"Heating up the nozzle,please wait..."
#define FILAMENT_DIALOG_UNLOAD_HEAT_TIPS_IT		"Heating up the nozzle,please wait..."
#define FILAMENT_DIALOG_LOAD_CONFIRM1_TIPS_IT           "Heat completed,please load filament \nto extruder,and click <confirm> \nfor start loading."
#define FILAMENT_DIALOG_LOAD_CONFIRM2_TIPS_IT           "Please load filament to extruder,\nand click <confirm> for start loading."
#define FILAMENT_DIALOG_UNLOAD_CONFIRM_TIPS_IT          "Heat completed,please \nclick <confirm> for start unloading.!"
#define FILAMENT_DIALOG_LOADING_TIPS_IT                 "Is loading ,please wait!"
#define FILAMENT_DIALOG_UNLOADING_TIPS_IT               "Is unloading,please wait!"
#define FILAMENT_DIALOG_LOAD_COMPLETE_TIPS_IT           "Load filament completed,\nclick <confirm> for return!"
#define FILAMENT_DIALOG_UNLOAD_COMPLETE_TIPS_IT         "Unload filament completed,\nclick <confirm> for return!"
#define FILAMENT_DIALOG_EMPTY_TIPS_IT                   "filament detection switch is no pressed!"


#define PRE_HEAT_EXT_TEXT_IT				"E"
#define PRE_HEAT_BED_TEXT_IT				"Piano"

#define FILE_LOADING_IT				        "Caricamento......"
#define NO_FILE_AND_CHECK_IT				"Nessun file, \nper favore controllare di nuovo!"
#define NO_FILE_IT					        "Nessun file!"

#define EXTRUDER_TEMP_TEXT_IT				"T:"
#define EXTRUDER_E_LENGTH1_TEXT_IT          "E"
#define EXTRUDER_E_LENGTH2_TEXT_IT          "E"
#define EXTRUDER_E_LENGTH3_TEXT_IT          "E"

#define ABOUT_TYPE_TEXT_IT					"Type: MKS TFT"
#define ABOUT_VERSION_TEXT_IT				"Version: 3.0.0"
#define ABOUT_WIFI_TEXT_IT					"WIFI:"

#define PRINTING_OPERATION_IT				"Opzioni"
#define PRINTING_PAUSE_IT					"Pause"
#define PRINTING_TEMP_IT					"Temp."
#define PRINTING_CHANGESPEED_IT				"Velocità"
#define PRINTING_RESUME_IT					"Recupero"
#define PRINTING_STOP_IT					"Stop"
#define PRINTING_MORE_IT					"Di più"
#define PRINTING_EXTRUDER_IT			    "Estrude"
#define PRINTING_MOVE_IT              "Muovi"

#define EXTRUDER_SPEED_IT					"Estrude"
#define MOVE_SPEED_IT						"Muovi"
#define EXTRUDER_SPEED_STATE_IT				"Estrusione"
#define MOVE_SPEED_STATE_IT					"Movimento"
#define STEP_1PERCENT_IT					"1%"
#define STEP_5PERCENT_IT					"5%"
#define STEP_10PERCENT_IT					"10%"

#define TITLE_READYPRINT_IT						"Pronto"
#define TITLE_PREHEAT_IT						"Preris"
#define TITLE_MOVE_IT					                "Muovi"
#define TITLE_HOME_IT							"Home"
#define TITLE_EXTRUDE_IT						"Estrude"
#define TITLE_LEVELING_IT						"Livella"
#define TITLE_SET_IT							"Impostare"
#define TITLE_MORE_IT							"Di più"
#define TITLE_CHOOSEFILE_IT						"File"
#define TITLE_PRINTING_IT						"Stampa"
#define TITLE_OPERATION_IT						"Opzioni"
#define TITLE_ADJUST_IT							"Regolare"
#define	TITLE_WIRELESS_IT						"Wireless"
#define	TITLE_FILAMENT_IT						"Filamento"
#define TITLE_ABOUT_IT							"Circa"
#define TITLE_FAN_IT							"Ventola"
#define TITLE_LANGUAGE_IT						"Lingua"
#define TITLE_PAUSE_IT							"Pausa"
#define TITLE_CHANGESPEED_IT				    "Velocità"
#define TITLE_CLOUD_TEXT_IT				        "Cloud"
#define TITLE_DIALOG_CONFIRM_IT				"Confirm"
#define TITLE_FILESYS_IT							"FileSys"

#define AUTO_SHUTDOWN_IT					"Auto"
#define MANUAL_SHUTDOWN_IT					"Manuale"

#define DIALOG_CONFIRM_IT					"Conferma"
#define DIALOG_CANCLE_IT					"Cancella"
#define DIALOG_OK_IT						"OK"
#define DIALOG_RESET_IT						"Resettare"
#define DIALOG_RETRY_IT						"Riprovare"
#define DIALOG_DISABLE_IT					"Disable"
#define DIALOG_PRINT_MODEL_IT				"Gcode stampa?"
#define DIALOG_CANCEL_PRINT_IT				"Stop stampa?"
#define DIALOG_STOP_IT				"Stop"
#define DIALOG_REPRINT_FROM_BREAKPOINT_IT	"Continua a stampare dal \npunto di interruzione?"
#define DIALOG_UNBIND_PRINTER_IT		"Libero?"
#define DIALOG_ERROR_TIPS1_IT		        "Errore: nessun file, \nper favore controllare di nuovo."
#define DIALOG_ERROR_TIPS2_IT			"Errore: operazione non riuscita, \nsi prega di controllare se il baudrate del \ndisplay è lo stesso scheda madre"
#define DIALOG_ERROR_TIPS3_IT			"Errore: il nome del file o il \npercorso è troppo lungo!"
#define DIALOG_CLOSE_MACHINE_IT                 "Closing machine......"
#define DIALOG_UNBIND_PRINTER_IT                "Unbind the printer?"
#define DIALOG_WIFI_ENABLE_IT            "Abilita"
#define DIALOG_WIFI_DISABLE_IT           "Disabilitare"
#define DIALOG_TEXT_WIFI_ENABLE_IT       "permettere"
#define DIALOG_TEXT_WIFI_DISABLE_IT      "disabilitare"

#define DIALOG_TEXT_NO_TEMP_TIPS_IT     "Nessuna temperatura target,\n si prega di scegliere la temperatura predefinita\n o impostare la temperatura"
#define DIALOG_TEXT_DEFAULT_TEMP_IT     "difetto"
#define DIALOG_TEXT_SETTING_TEMP_IT     "impostare"

/*****************************************/

#endif
