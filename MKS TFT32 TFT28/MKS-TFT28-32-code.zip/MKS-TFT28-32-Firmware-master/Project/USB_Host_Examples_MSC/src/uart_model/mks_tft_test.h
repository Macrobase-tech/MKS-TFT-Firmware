#ifndef MKS_TFT_TEST_H
#define MKS_TFT_TEST_H

extern void mksCmdTest(void);

#endif